<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/mail.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function e(string $v): string
{
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function app_url(string $path): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    return $scheme . '://' . $host . BASE_URL . $path;
}

function redirect(string $path): never
{
    header('Location: ' . BASE_URL . $path);
    exit;
}

function flash(?string $m = null): ?string
{
    if ($m !== null) {
        $_SESSION['flash'] = $m;
        return null;
    }

    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);

    return $m;
}

function ensure_email_verification_columns(): void
{
    $columns = [
        'email_verified_at DATETIME NULL AFTER role',
        'verification_token VARCHAR(100) NULL AFTER email_verified_at',
        'email_otp VARCHAR(10) NULL AFTER verification_token',
        'otp_expires_at DATETIME NULL AFTER email_otp',
        'profile_image VARCHAR(255) NULL AFTER phone'
    ];

    foreach ($columns as $column) {
        try {
            db()->query('ALTER TABLE users ADD COLUMN ' . $column);
        } catch (Throwable $e) {
            // Column already exists.
        }
    }

    try {
        db()->query("UPDATE users SET email_verified_at = NOW() WHERE role = 'admin' AND email_verified_at IS NULL");
    } catch (Throwable $e) {
        // Keep the app running even if this update is not needed.
    }
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $s = db()->prepare('SELECT * FROM users WHERE id = ?');
    $s->execute([$_SESSION['user_id']]);

    return $s->fetch() ?: null;
}

function require_login(): array
{
    $u = current_user();

    if (!$u) {
        redirect('/auth/login.php');
    }

    return $u;
}

function require_admin(): array
{
    $u = require_login();

    if ($u['role'] !== 'admin') {
        redirect('/public/index.php');
    }

    return $u;
}

function admin_user(): ?array
{
    $s = db()->query("SELECT * FROM users WHERE role = 'admin' ORDER BY id LIMIT 1");
    return $s->fetch() ?: null;
}

function send_email_message(string $to, string $subject, string $message): bool
{
    if (!defined('SMTP_PASSWORD') || SMTP_PASSWORD === '') {
        return false;
    }

    $socket = stream_socket_client('tcp://' . SMTP_HOST . ':' . SMTP_PORT, $errno, $errstr, 30);

    if (!$socket) {
        return false;
    }

    $read = function () use ($socket): string {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return $response;
    };

    $write = function (string $command) use ($socket): void {
        fwrite($socket, $command . "\r\n");
    };

    $expect = function (array $codes) use ($read): bool {
        $response = $read();
        return in_array(substr($response, 0, 3), $codes, true);
    };

    if (!$expect(['220'])) {
        fclose($socket);
        return false;
    }

    $write('EHLO localhost');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }

    $write('STARTTLS');
    if (!$expect(['220'])) {
        fclose($socket);
        return false;
    }

    if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
        fclose($socket);
        return false;
    }

    $write('EHLO localhost');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }

    $write('AUTH LOGIN');
    if (!$expect(['334'])) {
        fclose($socket);
        return false;
    }

    $write(base64_encode(SMTP_USERNAME));
    if (!$expect(['334'])) {
        fclose($socket);
        return false;
    }

    $write(base64_encode(SMTP_PASSWORD));
    if (!$expect(['235'])) {
        fclose($socket);
        return false;
    }

    $fromEmail = SMTP_FROM_EMAIL;
    $fromName = SMTP_FROM_NAME;

    $write('MAIL FROM:<' . $fromEmail . '>');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }

    $write('RCPT TO:<' . $to . '>');
    if (!$expect(['250', '251'])) {
        fclose($socket);
        return false;
    }

    $write('DATA');
    if (!$expect(['354'])) {
        fclose($socket);
        return false;
    }

    $headers = [];
    $headers[] = 'From: ' . $fromName . ' <' . $fromEmail . '>';
    $headers[] = 'To: ' . $to;
    $headers[] = 'Subject: ' . $subject;
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';

    $body = implode("\r\n", $headers) . "\r\n\r\n" . $message . "\r\n.";
    $write($body);

    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }

    $write('QUIT');
    fclose($socket);

    return true;
}
function notify_user(int $uid, string $type, string $message): void
{
    db()->prepare('INSERT INTO notifications(user_id, type, message) VALUES(?, ?, ?)')
        ->execute([$uid, $type, $message]);
}

function notify_user_email(int $uid, string $subject, string $message): void
{
    $s = db()->prepare('SELECT * FROM users WHERE id = ?');
    $s->execute([$uid]);
    $user = $s->fetch();

    if (!$user) {
        return;
    }

    notify_user($uid, 'email', $message);
    send_email_message($user['email'], $subject, $message);
}

function notify_admin_email(string $subject, string $message): void
{
    $admin = admin_user();

    if (!$admin) {
        return;
    }

    notify_user((int)$admin['id'], 'email', $message);
    send_email_message($admin['email'], $subject, $message);
}

function send_otp_email(int $userId, string $email, string $otp): bool
{
    $subject = 'Your Chiya Mahol verification OTP';
    $message = "Namaste,\n\nYour Chiya Mahol email verification OTP is: $otp\n\nThis OTP expires in 10 minutes.\n\nThank you.";

    notify_user($userId, 'email', 'OTP sent for email verification.');
    return send_email_message($email, $subject, $message);
}

function order_items_for_order(int $orderId): array
{
    $s = db()->prepare(
        'SELECT f.name, f.image_url, oi.quantity, oi.price, (oi.quantity * oi.price) line_total
         FROM order_items oi
         JOIN foods f ON f.id = oi.food_id
         WHERE oi.order_id = ?
         ORDER BY f.name'
    );
    $s->execute([$orderId]);

    return $s->fetchAll();
}

function order_items_label(int $orderId): string
{
    $items = order_items_for_order($orderId);

    if (!$items) {
        return 'No food items found';
    }

    return implode(', ', array_map(
        fn($item) => $item['quantity'] . ' x ' . $item['name'],
        $items
    ));
}

function order_items_email_block(int $orderId): string
{
    $items = order_items_for_order($orderId);

    if (!$items) {
        return "Food items: No food items found\n";
    }

    $lines = ["Food items ordered:"];
    foreach ($items as $item) {
        $lines[] = '- ' . $item['quantity'] . ' x ' . $item['name'] . ' @ Rs. ' . number_format((float)$item['price'], 2) . ' = Rs. ' . number_format((float)$item['line_total'], 2);
    }

    return implode("\n", $lines) . "\n";
}
function notify_order_status(int $orderId, string $status): void
{
    $s = db()->prepare('SELECT o.*, u.name, u.email FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ?');
    $s->execute([$orderId]);
    $order = $s->fetch();

    if (!$order) {
        return;
    }

    $label = ucwords($status);
    $itemsBlock = order_items_email_block($orderId);
    $scheduled = !empty($order['scheduled_at']) ? $order['scheduled_at'] : 'As soon as possible';
    $instructions = trim((string)($order['special_instructions'] ?? ''));
    $instructionLine = $instructions !== '' ? $instructions : 'No special instructions';

    $customerMessage = "Namaste {$order['name']},\n\n"
        . "Your Chiya Mahol order #$orderId is now: $label.\n\n"
        . $itemsBlock . "\n"
        . "Order type: " . ucwords($order['order_type']) . "\n"
        . "Payment method: " . ucwords($order['payment_method']) . "\n"
        . "Location: " . ($order['order_location'] ?: 'Not provided') . "\n"
        . "Scheduled time: $scheduled\n"
        . "Special instructions: $instructionLine\n"
        . "Total amount: Rs. " . number_format((float)$order['total'], 2) . "\n\n"
        . "We will keep you updated as your food moves through received, preparing, out for delivery, and delivered.\n\n"
        . "Thank you for ordering from Chiya Mahol.";

    $adminMessage = "Order #$orderId for {$order['name']} is now $label.\n\n"
        . $itemsBlock . "\n"
        . "Customer email: {$order['email']}\n"
        . "Order type: " . ucwords($order['order_type']) . "\n"
        . "Payment method: " . ucwords($order['payment_method']) . "\n"
        . "Location: " . ($order['order_location'] ?: 'Not provided') . "\n"
        . "Scheduled time: $scheduled\n"
        . "Special instructions: $instructionLine\n"
        . "Total amount: Rs. " . number_format((float)$order['total'], 2) . "\n";

    notify_user_email((int)$order['user_id'], "Chiya Mahol Order #$orderId - $label", $customerMessage);
    notify_admin_email("Chiya Mahol Order #$orderId - $label", $adminMessage);
}

function ensure_order_stock_column(): void
{
    try {
        db()->query('ALTER TABLE orders ADD COLUMN stock_reduced_at DATETIME NULL AFTER status');
        db()->query('UPDATE orders SET stock_reduced_at = created_at WHERE stock_reduced_at IS NULL');
    } catch (Throwable $e) {
        // Column already exists.
    }
}

function reduce_order_inventory_when_preparing(int $orderId): array
{
    ensure_order_stock_column();

    $pdo = db();
    $pdo->beginTransaction();

    try {
        $orderStmt = $pdo->prepare('SELECT id, stock_reduced_at FROM orders WHERE id = ? FOR UPDATE');
        $orderStmt->execute([$orderId]);
        $order = $orderStmt->fetch();

        if (!$order) {
            $pdo->rollBack();
            return ['reduced' => false, 'message' => 'Order not found.'];
        }

        if (!empty($order['stock_reduced_at'])) {
            $pdo->commit();
            return ['reduced' => false, 'message' => 'Inventory was already reduced for this order.'];
        }

        $recipeStmt = $pdo->prepare(
            'SELECT i.id, i.name, i.unit, SUM(r.quantity_required * oi.quantity) required_qty
             FROM order_items oi
             JOIN recipes r ON r.food_id = oi.food_id
             JOIN inventory_items i ON i.id = r.inventory_item_id
             WHERE oi.order_id = ?
             GROUP BY i.id, i.name, i.unit'
        );
        $recipeStmt->execute([$orderId]);
        $ingredients = $recipeStmt->fetchAll();

        foreach ($ingredients as $ingredient) {
            $pdo->prepare('UPDATE inventory_items SET quantity = GREATEST(0, quantity - ?) WHERE id = ?')
                ->execute([(float)$ingredient['required_qty'], (int)$ingredient['id']]);
        }

        $pdo->prepare('UPDATE orders SET stock_reduced_at = NOW() WHERE id = ?')
            ->execute([$orderId]);

        $pdo->commit();

        if (!$ingredients) {
            return ['reduced' => true, 'message' => 'No recipe ingredients were configured for this order.'];
        }

        $parts = [];
        foreach ($ingredients as $ingredient) {
            $parts[] = $ingredient['name'] . ' - ' . number_format((float)$ingredient['required_qty'], 2) . ' ' . $ingredient['unit'];
        }

        return ['reduced' => true, 'message' => 'Inventory reduced: ' . implode(', ', $parts) . '.'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        throw $e;
    }
}
function cart_items(): array
{
    $cart = $_SESSION['cart'] ?? [];

    if (!$cart) {
        return [];
    }

    $ids = array_keys($cart);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $s = db()->prepare("SELECT * FROM foods WHERE id IN ($ph)");
    $s->execute($ids);

    $items = [];
    foreach ($s->fetchAll() as $food) {
        $q = (int)$cart[$food['id']];
        $food['quantity'] = $q;
        $food['line_total'] = $q * (float)$food['price'];
        $items[] = $food;
    }

    return $items;
}

function cart_summary(?string $code = null): array
{
    $subtotal = array_sum(array_column(cart_items(), 'line_total'));
    $discount = 0.0;
    $coupon = null;

    if ($code) {
        $s = db()->prepare('SELECT * FROM coupons WHERE code = ? AND is_active = 1');
        $s->execute([$code]);
        $coupon = $s->fetch();

        if ($coupon) {
            $discount = $coupon['type'] === 'percent'
                ? $subtotal * ((float)$coupon['value'] / 100)
                : (float)$coupon['value'];
        }
    }

    $discount = min($discount, $subtotal);
    $tax = max(0, $subtotal - $discount) * 0.13;
    $delivery = $subtotal > 0 ? 80.0 : 0.0;
    $total = max(0, $subtotal - $discount) + $tax + $delivery;

    return compact('subtotal', 'discount', 'tax', 'delivery', 'total', 'coupon');
}

function low_stock_count(): int
{
    return (int)db()->query('SELECT COUNT(*) FROM inventory_items WHERE quantity <= low_stock_level')->fetchColumn();
}

function expiring_count(): int
{
    return (int)db()->query("SELECT COUNT(*) FROM inventory_items WHERE expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)")->fetchColumn();
}




