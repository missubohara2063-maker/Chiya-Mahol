</main>
<footer class="footer">
<p>&copy; <?= date('Y') ?>
Chiya Mahol. Food Ordering and Inventory Management System.</p>
</footer>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=19">
</script>
</body>
</html>

