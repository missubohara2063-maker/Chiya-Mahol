<?php
require_once __DIR__ . '/functions.php';
$user = current_user();
$userName = $user['name'] ?? '';
$initials = $userName !== '' ? strtoupper(substr(trim($userName), 0, 1)) : 'U';
$profileImage = $user['profile_image'] ?? '';
$profileHref = $user && $user['role'] === 'admin' ? BASE_URL . '/admin/index.php' : BASE_URL . '/public/profile.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=22">
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?= BASE_URL ?>/public/index.php" aria-label="Chiya Mahol home">
        <img class="brand-logo" src="<?= BASE_URL ?>/assets/images/brand-logo-new.png?v=18" alt="Chiya Mahol logo">
        <span>Chiya Mahol</span>
    </a>

    <nav class="main-nav" aria-label="Main navigation">
        <a href="<?= BASE_URL ?>/public/menu.php">
            <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 6.5c-2.4-1.6-5.2-2-8-1.1v13.2c2.8-.9 5.6-.5 8 1.1V6.5Z"/><path d="M12 6.5c2.4-1.6 5.2-2 8-1.1v13.2c-2.8-.9-5.6-.5-8 1.1V6.5Z"/><path d="M12 6.5v13.2"/></svg></span>
            <span>Menu</span>
        </a>
        <a href="<?= BASE_URL ?>/public/cart.php">
            <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 7h2l1.4 8.4a2 2 0 0 0 2 1.6h6.9a2 2 0 0 0 1.9-1.4L21 10H8"/><path d="M9 7a3 3 0 0 1 6 0"/><circle cx="10" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/></svg></span>
            <span>Cart</span>
        </a>
        <a href="<?= BASE_URL ?>/public/reservation.php">
            <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 10h16"/><path d="M6 10v10M18 10v10"/><path d="M7 4h10a3 3 0 0 1 3 3v3H4V7a3 3 0 0 1 3-3Z"/></svg></span>
            <span>Reservation</span>
        </a>

        <?php if ($user): ?>
            <a class="profile-chip" href="<?= e($profileHref) ?>" aria-label="Open profile">
                <?php if ($profileImage): ?>
                    <img class="avatar avatar-img" src="<?= BASE_URL ?>/<?= e($profileImage) ?>" alt="Profile picture">
                <?php else: ?>
                    <span class="avatar"><?= e($initials) ?></span>
                <?php endif; ?>
                <span class="profile-copy"><span>Hi <?= e($userName) ?></span></span>
            </a>
            <a class="logout-link" href="<?= BASE_URL ?>/auth/logout.php">
                <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M12 3h7v18h-7"/></svg></span>
                <span>Logout</span>
            </a>
        <?php else: ?>
            <a href="<?= BASE_URL ?>/auth/login.php">
                <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M15 3h4v18h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/></svg></span>
                <span>Login</span>
            </a>
            <a class="button small" href="<?= BASE_URL ?>/auth/register.php">Sign Up</a>
        <?php endif; ?>
    </nav>
</header>

<?php if ($msg = flash()): ?>
    <div class="flash"><?= e($msg) ?></div>
<?php endif; ?>

<main class="container">















