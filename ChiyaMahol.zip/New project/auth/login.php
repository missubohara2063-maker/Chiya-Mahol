<?php
require_once __DIR__ . '/../includes/functions.php';

ensure_email_verification_columns();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = db()->prepare('SELECT * FROM users WHERE email = ?');
    $s->execute([trim($_POST['email'])]);
    $u = $s->fetch();

    $passwordOk = $u && (password_verify($_POST['password'], $u['password']) || hash_equals($u['password'], $_POST['password']));

    if ($passwordOk) {
        if ($u['role'] === 'customer' && empty($u['email_verified_at'])) {
            flash('This account was not verified during signup. Please complete OTP verification from the signup flow.');
            redirect('/auth/login.php');
        }

        $_SESSION['user_id'] = $u['id'];
        redirect($u['role'] === 'admin' ? '/admin/index.php' : '/public/index.php');
    }

    flash('Invalid email or password.');
}

require_once __DIR__ . '/../includes/header.php';
?>
<section class="auth-card auth-panel">
    <p class="eyebrow">Welcome back</p>
    <h1>Login</h1>

    <form method="post" class="form">
        <input name="email" type="email" placeholder="Email" required>
        <input name="password" type="password" placeholder="Password" required>
        <button class="button">Login</button>
    </form>

    <p class="auth-foot"><a href="<?= BASE_URL ?>/auth/forgot.php">Forgot password?</a></p>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
