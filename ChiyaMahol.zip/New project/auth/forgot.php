<?php
require_once __DIR__.'/../includes/functions.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
flash('Password recovery link demo sent to your email/phone.');
redirect('/auth/login.php');
}
require_once __DIR__.'/../includes/header.php';
?>
<section class="auth-card">
<h1>Password Recovery</h1>
<form method="post" class="form">
<input name="identity" placeholder="Email or phone" required>
<button class="button">Send Recovery Link</button>
</form>
</section>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
