<?php
require_once __DIR__.'/../includes/functions.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
$id=(int)$_POST['food_id'];
$_SESSION['cart'][$id]=($_SESSION['cart'][$id]??0)+1;
flash('Item added to cart.');
redirect('/public/menu.php');
}
$category=$_GET['category']??'';
$search=trim($_GET['search']??'');
$params=[];
$where=['1=1'];
if($category!==''){
$where[]='c.id=?';
$params[]=$category;
}
if($search!==''){
$where[]='f.name LIKE ?';
$params[]="%$search%";
}
$s=db()->prepare('SELECT f.*, c.name category_name FROM foods f JOIN categories c ON c.id=f.category_id WHERE '.implode(' AND ',$where).' ORDER BY f.name');
$s->execute($params);
$foods=$s->fetchAll();
$cats=db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<section class="page-head">
<h1>Food Menu</h1>
<form class="filters">
<input name="search" value="<?= e($search) ?>" placeholder="Search food">
<select name="category">
<option value="">All categories</option>
<?php
foreach($cats as $c): ?>
<option value="<?= $c['id'] ?>" <?= (string)$c['id']===(string)$category?'selected':'' ?>>
<?= e($c['name']) ?>
</option>
<?php
endforeach;
?>
</select>
<button class="button small">Filter</button>
</form>
</section>
<section class="food-grid">
<?php
foreach($foods as $f): ?>
<article class="food-card">
<img src="<?= e($f['image_url']) ?>" alt="<?= e($f['name']) ?>">
<div>
<span class="pill">
<?= e($f['category_name']) ?>
</span>
<h3>
<?= e($f['name']) ?>
</h3>
<p>
<?= e($f['description']) ?>
</p>
<strong>Rs. <?= number_format((float)$f['price'],2) ?>
</strong>
<p class="<?= $f['is_available']?'ok':'danger' ?>">
<?= $f['is_available']?'Available':'Unavailable' ?>
</p>
<form method="post">
<input type="hidden" name="food_id" value="<?= $f['id'] ?>">
<button class="button small" <?= $f['is_available']?'':'disabled' ?>>Add to Cart</button>
<a class="ghost small" href="<?= BASE_URL ?>/public/review.php?food_id=<?= $f['id'] ?>">Reviews</a>
</form>
</div>
</article>
<?php
endforeach;
?>
</section>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
