<?php
require_once __DIR__.'/../includes/functions.php';
$u=require_login();
$s=db()->prepare('SELECT * FROM orders WHERE id=? AND user_id=?');
$s->execute([(int)$_GET['id'],$u['id']]);
$o=$s->fetch();
if(!$o){
flash('Order not found.');
redirect('/public/profile.php');
}
$steps=['received','preparing','out for delivery','delivered'];
require_once __DIR__.'/../includes/header.php';
?>
<h1>Order Tracking #<?= $o['id'] ?>
</h1>
<div class="tracker">
<?php
foreach($steps as $st): ?>
<div class="<?= array_search($st,$steps,true)<=array_search($o['status'],$steps,true)?'active':'' ?>">
<?= e(ucwords($st)) ?>
</div>
<?php
endforeach;
?>
</div>
<p>Total: Rs. <?= number_format((float)$o['total'],2) ?>
</p>
<p>Payment: <?= e($o['payment_method']) ?>
</p>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
