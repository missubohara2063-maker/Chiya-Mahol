<?php
require_once __DIR__.'/../includes/functions.php';
$foodId=(int)($_GET['food_id']??$_POST['food_id']??0);
$user=current_user();
if($_SERVER['REQUEST_METHOD']==='POST'){
$user=require_login();
db()->prepare('INSERT INTO reviews(user_id,food_id,rating,comment) VALUES(?,?,?,?)')->execute([$user['id'],$foodId,(int)$_POST['rating'],trim($_POST['comment'])]);
flash('Review submitted.');
redirect('/public/review.php?food_id='.$foodId);
}
$food=db()->prepare('SELECT * FROM foods WHERE id=?');
$food->execute([$foodId]);
$food=$food->fetch();
$s=db()->prepare('SELECT r.*,u.name FROM reviews r JOIN users u ON u.id=r.user_id WHERE food_id=? ORDER BY r.created_at DESC');
$s->execute([$foodId]);
require_once __DIR__.'/../includes/header.php';
?>
<h1>Reviews for <?= e($food['name']??'Food') ?>
</h1>
<?php
if($user): ?>
<form method="post" class="form">
<input type="hidden" name="food_id" value="<?= $foodId ?>">
<select name="rating">
<option>5</option>
<option>4</option>
<option>3</option>
<option>2</option>
<option>1</option>
</select>
<textarea name="comment" placeholder="Customer feedback">
</textarea>
<button class="button">Submit Review</button>
</form>
<?php
endif;
?>
<section class="list">
<?php
foreach($s->fetchAll() as $r): ?>
<article>
<strong>
<?= e($r['name']) ?>
rated <?= $r['rating'] ?>/5</strong>
<p>
<?= e($r['comment']) ?>
</p>
</article>
<?php
endforeach;
?>
</section>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
