<?php
require_once __DIR__.'/../includes/header.php';
?>
<section class="hero">
<div>
<p class="eyebrow">Tea, snacks, meals, and smooth service</p>
<h1>Chiya Mahol</h1>
<p>Order food, reserve tables, track delivery, and help the restaurant manage inventory from one system.</p>
<a class="button" href="<?= BASE_URL ?>/public/menu.php">Order Now</a>
</div>
</section>
<section class="grid three">
<article>
<h3>Fast Ordering</h3>
<p>Dine-in, takeaway, delivery, scheduled orders, and special instructions.</p>
</article>
<article>
<h3>Live Tracking</h3>
<p>Follow order status from received to delivered.</p>
</article>
<article>
<h3>Inventory Control</h3>
<p>Stock automatically decreases when food is ordered.</p>
</article>
</section>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
