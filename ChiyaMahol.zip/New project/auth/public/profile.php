<?php
require_once __DIR__.'/../includes/functions.php';
$u=require_login();
$orders=db()->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC');
$orders->execute([$u['id']]);
$addr=db()->prepare('SELECT * FROM addresses WHERE user_id=?');
$addr->execute([$u['id']]);
$fav=db()->prepare('SELECT f.* FROM favorites fav JOIN foods f ON f.id=fav.food_id WHERE fav.user_id=?');
$fav->execute([$u['id']]);
require_once __DIR__.'/../includes/header.php';
?>
<h1>Customer Profile</h1>
<section class="grid three">
<article>
<h3>
<?= e($u['name']) ?>
</h3>
<p>
<?= e($u['email']) ?>
<br>
<?= e($u['phone']) ?>
</p>
</article>
<article>
<h3>Saved Addresses</h3>
<?php
foreach($addr as $a): ?>
<p>
<?= e($a['label']) ?>
: <?= e($a['address']) ?>
</p>
<?php
endforeach;
?>
</article>
<article>
<h3>Favorite Foods</h3>
<?php
foreach($fav as $f): ?>
<p>
<?= e($f['name']) ?>
</p>
<?php
endforeach;
?>
</article>
</section>
<h2>Order History</h2>
<div class="table-wrap">
<table>
<tr>
<th>ID</th>
<th>Status</th>
<th>Total</th>
<th>Date</th>
<th>
</th>
</tr>
<?php
foreach($orders as $o): ?>
<tr>
<td>#<?= $o['id'] ?>
</td>
<td>
<?= e($o['status']) ?>
</td>
<td>Rs. <?= number_format((float)$o['total'],2) ?>
</td>
<td>
<?= e($o['created_at']) ?>
</td>
<td>
<a href="<?= BASE_URL ?>/public/order_tracking.php?id=<?= $o['id'] ?>">Track</a>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
