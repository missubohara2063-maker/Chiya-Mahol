<?php
require_once __DIR__.'/../includes/functions.php';
$u=require_login();
if($_SERVER['REQUEST_METHOD']==='POST'){
db()->prepare('INSERT INTO reservations(user_id,table_no,guests,reserved_at,status) VALUES(?,?,?,?,"pending")')->execute([$u['id'],$_POST['table_no'],$_POST['guests'],$_POST['reserved_at']]);
flash('Table reservation requested.');
redirect('/public/profile.php');
}
require_once __DIR__.'/../includes/header.php';
?>
<h1>Table Reservation</h1>
<form method="post" class="form">
<input name="table_no" placeholder="Table number preference" required>
<input type="number" name="guests" placeholder="Guests" min="1" required>
<input type="datetime-local" name="reserved_at" required>
<button class="button">Reserve Table</button>
</form>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
