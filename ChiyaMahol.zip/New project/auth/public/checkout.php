<?php
require_once __DIR__.'/../includes/functions.php';
$user=require_login();
$items=cart_items();
if(!$items){
flash('Your cart is empty.');
redirect('/public/menu.php');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
$sum=cart_summary($_SESSION['coupon']??null);
$pdo=db();
$pdo->beginTransaction();
$s=$pdo->prepare('INSERT INTO orders(user_id,order_type,payment_method,subtotal,discount,tax,delivery_charge,total,scheduled_at,special_instructions,status) VALUES(?,?,?,?,?,?,?,?,?,?,"received")');
$s->execute([$user['id'],$_POST['order_type'],$_POST['payment_method'],$sum['subtotal'],$sum['discount'],$sum['tax'],$sum['delivery'],$sum['total'],$_POST['scheduled_at']?:null,trim($_POST['special_instructions'])]);
$oid=(int)$pdo->lastInsertId();
foreach($items as $item){
$pdo->prepare('INSERT INTO order_items(order_id,food_id,quantity,price) VALUES(?,?,?,?)')->execute([$oid,$item['id'],$item['quantity'],$item['price']]);
$r=$pdo->prepare('SELECT * FROM recipes WHERE food_id=?');
$r->execute([$item['id']]);
foreach($r->fetchAll() as $ing){
$pdo->prepare('UPDATE inventory_items SET quantity=GREATEST(0, quantity-?) WHERE id=?')->execute([(float)$ing['quantity_required']*(int)$item['quantity'],$ing['inventory_item_id']]);
}
}
notify_user((int)$user['id'],'email',"Order #$oid confirmed.");
notify_user((int)$user['id'],'sms',"Your Chiya Mahol order #$oid is received.");
$pdo->commit();
unset($_SESSION['cart'],$_SESSION['coupon']);
flash('Order placed successfully.');
redirect('/public/order_tracking.php?id='.$oid);
}
require_once __DIR__.'/../includes/header.php';
?>
<h1>Checkout</h1>
<form method="post" class="form wide">
<label>Order Type<select name="order_type" required>
<option>dine-in</option>
<option>takeaway</option>
<option>delivery</option>
</select>
</label>
<label>Payment<select name="payment_method" required>
<option>cash on delivery</option>
<option>digital wallet</option>
<option>card payment</option>
<option>qr payment</option>
</select>
</label>
<label>Schedule for later<input type="datetime-local" name="scheduled_at">
</label>
<textarea name="special_instructions" placeholder="Special instructions for food">
</textarea>
<button class="button">Place Order</button>
</form>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
