<?php
require_once __DIR__ . '/../includes/functions.php';

ensure_email_verification_columns();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('Please enter a valid email address.');
        redirect('/auth/register.php');
    }

    $existing = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $existing->execute([$email]);
    $existingUser = $existing->fetch();

    if ($existingUser && ($existingUser['role'] === 'admin' || !empty($existingUser['email_verified_at']))) {
        flash('This email is already registered. Please login or use a different email.');
        redirect('/auth/register.php');
    }

    $otp = (string)random_int(100000, 999999);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    if ($existingUser) {
        db()->prepare('UPDATE users SET name = ?, phone = ?, password = ?, email_otp = ?, otp_expires_at = ? WHERE id = ?')
            ->execute([$name, $phone, password_hash($_POST['password'], PASSWORD_DEFAULT), $otp, $expiresAt, $existingUser['id']]);
        $userId = (int)$existingUser['id'];
    } else {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $s = db()->prepare('INSERT INTO users(name, email, phone, password, role, email_otp, otp_expires_at) VALUES(?, ?, ?, ?, "customer", ?, ?)');
        $s->execute([$name, $email, $phone, $password, $otp, $expiresAt]);
        $userId = (int)db()->lastInsertId();
    }

    $sent = send_otp_email($userId, $email, $otp);
    $_SESSION['pending_verification_email'] = $email;

    if ($sent) {
        flash('Account created. Please enter the OTP sent to your email.');
    } else {
        flash('Account created, but OTP email could not be sent. Please check SMTP settings.');
    }

    redirect('/auth/verify_otp.php');
}

require_once __DIR__ . '/../includes/header.php';
?>
<section class="auth-card">
    <h1>Create Account</h1>
    <form method="post" class="form">
        <input name="name" placeholder="Full name" required>
        <input name="email" type="email" placeholder="Email" required>
        <input name="phone" placeholder="Phone number" required>
        <input name="password" type="password" placeholder="Password" required>
        <button class="button">Register</button>
    </form>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>