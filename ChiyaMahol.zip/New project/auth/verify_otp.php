<?php
require_once __DIR__ . '/../includes/functions.php';

ensure_email_verification_columns();

$email = $_SESSION['pending_verification_email'] ?? ($_GET['email'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $otp = trim($_POST['otp']);

    $s = db()->prepare('SELECT * FROM users WHERE email = ? AND role = "customer" LIMIT 1');
    $s->execute([$email]);
    $user = $s->fetch();

    if (!$user) {
        flash('We could not find a customer account with that email.');
        redirect('/auth/verify_otp.php');
    }

    if (!empty($user['email_verified_at'])) {
        flash('Your email is already verified. Please login.');
        redirect('/auth/login.php');
    }

    if ($user['email_otp'] !== $otp) {
        flash('The OTP is incorrect. Please enter the 6 digit code sent to your email.');
        redirect('/auth/verify_otp.php');
    }

    if (empty($user['otp_expires_at']) || strtotime($user['otp_expires_at']) < time()) {
        flash('Your OTP has expired. Please request a new OTP.');
        redirect('/auth/resend_otp.php');
    }

    db()->prepare('UPDATE users SET email_verified_at = NOW(), email_otp = NULL, otp_expires_at = NULL WHERE id = ?')
        ->execute([$user['id']]);

    unset($_SESSION['pending_verification_email']);
    notify_user((int)$user['id'], 'app', 'Your email address has been verified successfully.');
    flash('Email verified successfully. You can login now.');
    redirect('/auth/login.php');
}

require_once __DIR__ . '/../includes/header.php';
?>
<section class="auth-card">
    <p class="eyebrow">Secure signup</p>
    <h1>Verify Your Email</h1>
    <p>We sent a 6 digit OTP to your email address. Enter the code below to activate your account.</p>

    <form method="post" class="form">
        <input name="email" type="email" value="<?= e($email) ?>" placeholder="Registered email" required>
        <input name="otp" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" placeholder="6 digit OTP" required>
        <button class="button">Verify OTP</button>
    </form>

    <form method="post" action="<?= BASE_URL ?>/auth/resend_otp.php" class="inline-actions">
        <input type="hidden" name="email" value="<?= e($email) ?>">
        <button class="ghost" type="submit">Send OTP Again</button>
    </form>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>