<?php
require_once __DIR__ . '/../includes/functions.php';

ensure_email_verification_columns();

$email = $_SESSION['pending_verification_email'] ?? ($_GET['email'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $s = db()->prepare('SELECT * FROM users WHERE email = ? AND role = "customer" LIMIT 1');
    $s->execute([$email]);
    $user = $s->fetch();

    if (!$user) {
        flash('No customer account found for this email.');
        redirect('/auth/resend_otp.php');
    }

    if (!empty($user['email_verified_at'])) {
        flash('Email already verified. Please login.');
        redirect('/auth/login.php');
    }

    $otp = (string)random_int(100000, 999999);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));

    db()->prepare('UPDATE users SET email_otp = ?, otp_expires_at = ? WHERE id = ?')
        ->execute([$otp, $expiresAt, $user['id']]);

    $_SESSION['pending_verification_email'] = $email;
    send_otp_email((int)$user['id'], $email, $otp);

    flash('New OTP sent to your email.');
    redirect('/auth/verify_otp.php');
}

require_once __DIR__ . '/../includes/header.php';
?>
<section class="auth-card">
    <h1>Resend OTP</h1>
    <form method="post" class="form">
        <input name="email" type="email" value="<?= e($email) ?>" placeholder="Registered email" required>
        <button class="button">Send OTP Again</button>
    </form>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>