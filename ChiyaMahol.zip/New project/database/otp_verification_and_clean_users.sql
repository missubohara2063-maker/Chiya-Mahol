﻿ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at DATETIME NULL AFTER role;
ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_token VARCHAR(100) NULL AFTER email_verified_at;
ALTER TABLE users ADD COLUMN IF NOT EXISTS email_otp VARCHAR(10) NULL AFTER verification_token;
ALTER TABLE users ADD COLUMN IF NOT EXISTS otp_expires_at DATETIME NULL AFTER email_otp;

DELETE d FROM deliveries d JOIN orders o ON o.id = d.order_id JOIN users u ON u.id = o.user_id WHERE u.role = 'customer';
DELETE oi FROM order_items oi JOIN orders o ON o.id = oi.order_id JOIN users u ON u.id = o.user_id WHERE u.role = 'customer';
DELETE FROM orders WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM reservations WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM reviews WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM favorites WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM addresses WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM notifications WHERE user_id IN (SELECT id FROM users WHERE role = 'customer');
DELETE FROM users WHERE role = 'customer';

UPDATE users
SET email = 'missubohara2063@gmail.com', email_verified_at = NOW(), verification_token = NULL, email_otp = NULL, otp_expires_at = NULL
WHERE role = 'admin';

