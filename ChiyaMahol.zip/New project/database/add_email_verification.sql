﻿ALTER TABLE users ADD COLUMN email_verified_at DATETIME NULL AFTER role;
ALTER TABLE users ADD COLUMN verification_token VARCHAR(100) NULL AFTER email_verified_at;
UPDATE users SET email_verified_at = NOW() WHERE email_verified_at IS NULL;
