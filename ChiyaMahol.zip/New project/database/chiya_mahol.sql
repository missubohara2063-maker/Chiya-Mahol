DROP DATABASE IF EXISTS chiya_mahol;
CREATE DATABASE chiya_mahol CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE chiya_mahol;

CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), email VARCHAR(120) UNIQUE, phone VARCHAR(30), profile_image VARCHAR(255) NULL, password VARCHAR(255), role ENUM('customer','admin') DEFAULT 'customer', email_verified_at DATETIME NULL, verification_token VARCHAR(100) NULL, email_otp VARCHAR(10) NULL, otp_expires_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL);
CREATE TABLE foods (id INT AUTO_INCREMENT PRIMARY KEY, category_id INT, name VARCHAR(120), description TEXT, price DECIMAL(10,2), discount DECIMAL(10,2) DEFAULT 0, image_url VARCHAR(255), is_available TINYINT(1) DEFAULT 1, FOREIGN KEY(category_id) REFERENCES categories(id));
CREATE TABLE coupons (id INT AUTO_INCREMENT PRIMARY KEY, code VARCHAR(30) UNIQUE, type ENUM('percent','fixed'), value DECIMAL(10,2), is_active TINYINT(1) DEFAULT 1);
CREATE TABLE addresses (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, label VARCHAR(50), address VARCHAR(255), FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE favorites (user_id INT, food_id INT, PRIMARY KEY(user_id, food_id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(food_id) REFERENCES foods(id));
CREATE TABLE orders (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, order_type ENUM('dine-in','takeaway','delivery'), payment_method ENUM('cash on delivery','digital wallet','card payment','qr payment'), order_location VARCHAR(255) NULL, subtotal DECIMAL(10,2), discount DECIMAL(10,2), tax DECIMAL(10,2), delivery_charge DECIMAL(10,2), total DECIMAL(10,2), scheduled_at DATETIME NULL, special_instructions TEXT, status ENUM('received','preparing','out for delivery','delivered','cancelled') DEFAULT 'received', stock_reduced_at DATETIME NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE order_items (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT, food_id INT, quantity INT, price DECIMAL(10,2), FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(food_id) REFERENCES foods(id));
CREATE TABLE notifications (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, type ENUM('sms','email','app'), message TEXT, is_read TINYINT(1) DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE reviews (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, food_id INT, rating INT, comment TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(food_id) REFERENCES foods(id));
CREATE TABLE employees (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), phone VARCHAR(30), role ENUM('chef','cashier','delivery staff','manager'), salary DECIMAL(10,2), status ENUM('active','inactive') DEFAULT 'active');
CREATE TABLE deliveries (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT, employee_id INT, status ENUM('assigned','picked up','delivered') DEFAULT 'assigned', tracking_note VARCHAR(255), FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(employee_id) REFERENCES employees(id));
CREATE TABLE inventory_items (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120), unit ENUM('kg','liter','packet','piece'), quantity DECIMAL(10,2), low_stock_level DECIMAL(10,2), expiry_date DATE NULL);
CREATE TABLE recipes (id INT AUTO_INCREMENT PRIMARY KEY, food_id INT, inventory_item_id INT, quantity_required DECIMAL(10,2), FOREIGN KEY(food_id) REFERENCES foods(id), FOREIGN KEY(inventory_item_id) REFERENCES inventory_items(id));
CREATE TABLE suppliers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120), contact_person VARCHAR(100), phone VARCHAR(30), email VARCHAR(120), address VARCHAR(255));
CREATE TABLE purchases (id INT AUTO_INCREMENT PRIMARY KEY, supplier_id INT, inventory_item_id INT, quantity DECIMAL(10,2), unit_price DECIMAL(10,2), bill_no VARCHAR(50), purchased_at DATE, FOREIGN KEY(supplier_id) REFERENCES suppliers(id), FOREIGN KEY(inventory_item_id) REFERENCES inventory_items(id));
CREATE TABLE waste_records (id INT AUTO_INCREMENT PRIMARY KEY, inventory_item_id INT, quantity DECIMAL(10,2), reason VARCHAR(255), recorded_at DATE, FOREIGN KEY(inventory_item_id) REFERENCES inventory_items(id));
CREATE TABLE expenses (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(120), amount DECIMAL(10,2), expense_date DATE);
CREATE TABLE reservations (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT, table_no VARCHAR(20), guests INT, reserved_at DATETIME, status ENUM('pending','confirmed','cancelled') DEFAULT 'pending', FOREIGN KEY(user_id) REFERENCES users(id));

INSERT INTO users(name,email,phone,password,role,email_verified_at,verification_token,email_otp,otp_expires_at) VALUES
('Admin User','missubohara2063@gmail.com','9800000000','admin123','admin',NOW(),NULL,NULL,NULL);
INSERT INTO categories(name) VALUES ('Pizza'),('Burger'),('Drinks'),('Tea'),('Snacks');
INSERT INTO foods(category_id,name,description,price,discount,image_url,is_available) VALUES
(1,'Cheese Pizza','Mozzarella cheese, tomato sauce and herbs.',450,0,'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80',1),
(2,'Chicken Burger','Grilled chicken patty with fresh salad.',280,0,'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80',1),
(3,'Cold Coffee','Iced coffee with milk and chocolate.',180,0,'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=80',1),
(4,'Masala Chiya','Classic Nepali milk tea with spices.',60,0,'https://simpleindianmeals.com/wp-content/uploads/2022/10/Masala-Chai-Tea-720x720.jpg',1),
(5,'Chicken Momo','Steamed dumplings with spicy achar.',160,0,'/chiya_mahol/assets/images/veg-momo.jpg',1),
(6,'Chatpate','An intensely flavorful and crunchy mixed salad.',70,0,'https://junifoods.com/wp-content/uploads/2023/04/Chatpate-1024x693.png',1);
INSERT INTO coupons(code,type,value,is_active) VALUES ('CHIYA10','percent',10,1),('WELCOME50','fixed',50,1);
INSERT INTO employees(name,phone,role,salary,status) VALUES ('Ramesh Chef','9822222222','chef',25000,'active'),('Sita Cashier','9833333333','cashier',22000,'active'),('Bikash Delivery','9844444444','delivery staff',20000,'active');
INSERT INTO inventory_items(name,unit,quantity,low_stock_level,expiry_date) VALUES ('Cheese','kg',8,2,DATE_ADD(CURDATE(), INTERVAL 15 DAY)),('Dough','kg',10,3,DATE_ADD(CURDATE(), INTERVAL 5 DAY)),('Chicken Patty','piece',40,10,DATE_ADD(CURDATE(), INTERVAL 8 DAY)),('Tea Leaves','kg',4,1,DATE_ADD(CURDATE(), INTERVAL 60 DAY)),('Milk','liter',18,5,DATE_ADD(CURDATE(), INTERVAL 3 DAY)),('Burger Bun','piece',50,10,DATE_ADD(CURDATE(), INTERVAL 7 DAY)),('Lettuce','kg',5,1,DATE_ADD(CURDATE(), INTERVAL 4 DAY)),('Tomato','kg',8,2,DATE_ADD(CURDATE(), INTERVAL 5 DAY)),('Burger Sauce','liter',3,0.5,DATE_ADD(CURDATE(), INTERVAL 20 DAY)),('Coffee Powder','kg',4,1,DATE_ADD(CURDATE(), INTERVAL 90 DAY)),('Sugar','kg',12,3,DATE_ADD(CURDATE(), INTERVAL 120 DAY)),('Chicken Mince','kg',10,2,DATE_ADD(CURDATE(), INTERVAL 5 DAY)),('Momo Wrapper','piece',300,50,DATE_ADD(CURDATE(), INTERVAL 8 DAY)),('Cabbage','kg',8,2,DATE_ADD(CURDATE(), INTERVAL 6 DAY)),('Momo Masala','packet',20,5,DATE_ADD(CURDATE(), INTERVAL 180 DAY)),('Puffed Rice','kg',15,3,DATE_ADD(CURDATE(), INTERVAL 60 DAY)),('Sev','kg',6,1,DATE_ADD(CURDATE(), INTERVAL 45 DAY)),('Lemon','piece',80,15,DATE_ADD(CURDATE(), INTERVAL 10 DAY)),('Chatpate Masala','packet',25,5,DATE_ADD(CURDATE(), INTERVAL 180 DAY));
INSERT INTO recipes(food_id,inventory_item_id,quantity_required) VALUES (1,1,0.20),(1,2,0.30),(2,3,1),(2,6,1),(2,7,0.05),(2,8,0.05),(2,9,0.03),(3,5,0.20),(3,10,0.03),(3,11,0.02),(4,4,0.02),(4,5,0.20),(5,12,0.12),(5,13,10),(5,14,0.05),(5,15,0.05),(6,16,0.15),(6,17,0.05),(6,8,0.03),(6,18,1),(6,19,0.05);
INSERT INTO suppliers(name,contact_person,phone,email,address) VALUES ('Kathmandu Dairy','Nabin','9855555555','dairy@example.com','Kathmandu'),('Fresh Food Supply','Mina','9866666666','fresh@example.com','Lalitpur');
INSERT INTO purchases(supplier_id,inventory_item_id,quantity,unit_price,bill_no,purchased_at) VALUES (1,5,20,90,'BILL-101',CURDATE()),(2,1,5,700,'BILL-102',CURDATE());
INSERT INTO expenses(title,amount,expense_date) VALUES ('Rent',25000,CURDATE()),('Electricity',5000,CURDATE());










