document.addEventListener('change', (event) => {
    if (!event.target.matches('input[type="number"]')) {
        return;
    }

    const min = Number(event.target.min || 0);

    if (Number(event.target.value) < min) {
        event.target.value = min;
    }
});

document.addEventListener('click', (event) => {
    const filterButton = event.target.closest('[data-filter-group="orders"] button');

    if (!filterButton) {
        return;
    }

    const group = filterButton.closest('[data-filter-group="orders"]');
    const filter = filterButton.dataset.filter;

    group.querySelectorAll('button').forEach((button) => {
        button.classList.toggle('active', button === filterButton);
    });

    document.querySelectorAll('[data-order-status]').forEach((card) => {
        const show = filter === 'all' || card.dataset.orderStatus === filter;
        card.classList.toggle('is-hidden', !show);
    });
});

document.addEventListener('click', (event) => {
    const table = event.target.closest('.table-seat:not(.is-booked)');

    if (!table) {
        return;
    }

    table.classList.toggle('is-selected');

    const selectedTables = Array.from(document.querySelectorAll('.table-seat.is-selected'));
    const selectedInput = document.querySelector('#selectedTable');
    const selectedCopy = document.querySelector('.selected-table-copy');
    const selectedList = document.querySelector('.selected-table-list');
    const tableNames = selectedTables.map((item) => item.dataset.table);
    const totalSeats = selectedTables.reduce((sum, item) => sum + Number(item.dataset.chairs || 0), 0);

    if (selectedInput) {
        selectedInput.value = tableNames.join(',');
    }

    if (selectedCopy) {
        selectedCopy.textContent = tableNames.length
            ? `${tableNames.length} table(s) selected - ${totalSeats} total seats`
            : 'Select one or more tables from the floor plan.';
    }

    if (selectedList) {
        selectedList.innerHTML = tableNames.map((name) => `<span>${name}</span>`).join('');
    }
});

document.addEventListener('submit', (event) => {
    const form = event.target.closest('.reservation-form');

    if (!form) {
        return;
    }

    const selectedInput = form.querySelector('#selectedTable');
    const dateInput = form.querySelector('input[name="reserved_at"]');

    if (!selectedInput || !selectedInput.value.trim()) {
        event.preventDefault();
        alert('Please select at least one table from the floor plan.');
        return;
    }

    if (!dateInput || !dateInput.value) {
        return;
    }

    const time = dateInput.value.split('T')[1] || '';

    if (time < '08:00' || time > '21:00') {
        event.preventDefault();
        alert('Chiya Mahol table reservations are available only from 8:00 AM to 9:00 PM.');
    }
});
