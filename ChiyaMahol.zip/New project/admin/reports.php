<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$sales = db()->query('SELECT DATE(created_at) day, COUNT(*) orders, COALESCE(SUM(total), 0) total FROM orders GROUP BY DATE(created_at) ORDER BY day DESC LIMIT 10')->fetchAll();
$salesChart = array_reverse($sales);
$best = db()->query('SELECT f.name, SUM(oi.quantity) qty FROM order_items oi JOIN foods f ON f.id = oi.food_id GROUP BY f.id ORDER BY qty DESC LIMIT 8')->fetchAll();
$stock = db()->query('SELECT * FROM inventory_items ORDER BY name')->fetchAll();
$statusRows = db()->query('SELECT status, COUNT(*) total FROM orders GROUP BY status')->fetchAll();
$revenue = (float)db()->query('SELECT COALESCE(SUM(total), 0) FROM orders')->fetchColumn();
$purchases = (float)db()->query('SELECT COALESCE(SUM(quantity * unit_price), 0) FROM purchases')->fetchColumn();
$expenses = (float)db()->query('SELECT COALESCE(SUM(amount), 0) FROM expenses')->fetchColumn();
$customers = db()->query('SELECT u.name, COUNT(o.id) orders, COALESCE(SUM(o.total), 0) spent FROM users u LEFT JOIN orders o ON o.user_id = u.id WHERE u.role = "customer" GROUP BY u.id ORDER BY orders DESC')->fetchAll();
$maxSales = max(1, ...(array_map(fn($row) => (float)$row['total'], $salesChart) ?: [0]));
$maxBest = max(1, ...(array_map(fn($row) => (float)$row['qty'], $best) ?: [0]));
$statusTotal = max(1, array_sum(array_column($statusRows, 'total')));
$colors = ['#28bdbb', '#128d8b', '#7a4a28', '#7ddad8', '#c0392b'];
$segments = [];
$start = 0;
foreach ($statusRows as $i => $row) {
    $angle = ((int)$row['total'] / $statusTotal) * 360;
    $segments[] = ($colors[$i % count($colors)] . ' ' . $start . 'deg ' . ($start + $angle) . 'deg');
    $start += $angle;
}
$pieStyle = $segments ? implode(', ', $segments) : '#dff8f7 0deg 360deg';

require_once __DIR__ . '/../includes/header.php';
?>
<section class="dashboard-shell reports-dashboard">
    <div class="dashboard-hero-card">
        <div>
            <p class="eyebrow">Reports and Analytics</p>
            <h1>Business Overview</h1>
            <p>Visual reports for sales, inventory, profit/loss, food performance, and customer activity.</p>
        </div>
        <div class="hero-metric">
            <span>Net Profit</span>
            <strong>Rs. <?= number_format($revenue - $purchases - $expenses, 0) ?></strong>
            <small>Revenue minus expenses</small>
        </div>
    </div>

    <section class="metric-grid">
        <article class="metric-card accent-a"><span>Revenue</span><strong>Rs. <?= number_format($revenue, 0) ?></strong><small>Total sales</small></article>
        <article class="metric-card accent-b"><span>Expenses</span><strong>Rs. <?= number_format($purchases + $expenses, 0) ?></strong><small>Purchases and costs</small></article>
        <article class="metric-card accent-c"><span>Stock Items</span><strong><?= count($stock) ?></strong><small><?= low_stock_count() ?> low stock</small></article>
        <article class="metric-card accent-d"><span>Customers</span><strong><?= count($customers) ?></strong><small>Registered customers</small></article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel wide-panel">
            <div class="panel-head"><div><p class="eyebrow">Bar Diagram</p><h2>Sales by Day</h2></div></div>
            <div class="bar-chart">
                <?php foreach ($salesChart as $row): ?>
                    <?php $height = max(8, ((float)$row['total'] / $maxSales) * 100); ?>
                    <div class="bar-item"><div class="bar-track"><span style="height: <?= $height ?>%"></span></div><small><?= date('M d', strtotime($row['day'])) ?></small></div>
                <?php endforeach; ?>
                <?php if (!$salesChart): ?><p class="muted">Sales graph will appear after orders.</p><?php endif; ?>
            </div>
        </article>

        <article class="dashboard-panel">
            <div class="panel-head"><div><p class="eyebrow">Pie Chart</p><h2>Order Status</h2></div></div>
            <div class="pie-wrap">
                <div class="pie-chart" style="background: conic-gradient(<?= e($pieStyle) ?>);"><span><?= $statusTotal ?></span></div>
                <div class="pie-legend">
                    <?php foreach ($statusRows as $i => $row): ?>
                        <div><span style="background: <?= e($colors[$i % count($colors)]) ?>"></span><?= e(ucwords($row['status'])) ?> (<?= $row['total'] ?>)</div>
                    <?php endforeach; ?>
                    <?php if (!$statusRows): ?><p class="muted">No orders yet.</p><?php endif; ?>
                </div>
            </div>
        </article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel">
            <div class="panel-head"><div><p class="eyebrow">Food Performance</p><h2>Best Selling Foods</h2></div></div>
            <div class="horizontal-bars">
                <?php foreach ($best as $row): ?>
                    <?php $width = max(8, ((float)$row['qty'] / $maxBest) * 100); ?>
                    <div class="hbar-row"><div><strong><?= e($row['name']) ?></strong><span><?= e($row['qty']) ?> sold</span></div><div class="hbar-track"><span style="width: <?= $width ?>%"></span></div></div>
                <?php endforeach; ?>
                <?php if (!$best): ?><p class="muted">Best-selling food report will appear after orders.</p><?php endif; ?>
            </div>
        </article>

        <article class="dashboard-panel wide-panel">
            <div class="panel-head"><div><p class="eyebrow">Inventory</p><h2>Current Stock</h2></div></div>
            <div class="table-wrap embedded-table"><table><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Expiry</th></tr><?php foreach ($stock as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['quantity']) ?></td><td><?= e($r['unit']) ?></td><td><?= e($r['expiry_date'] ?? '') ?></td></tr><?php endforeach; ?></table></div>
        </article>
    </section>

    <section class="dashboard-panel">
        <div class="panel-head"><div><p class="eyebrow">Customer Analytics</p><h2>Most Active Customers</h2></div></div>
        <div class="table-wrap embedded-table"><table><tr><th>Customer</th><th>Orders</th><th>Spent</th></tr><?php foreach ($customers as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['orders']) ?></td><td>Rs. <?= number_format((float)$r['spent'], 2) ?></td></tr><?php endforeach; ?></table></div>
    </section>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>