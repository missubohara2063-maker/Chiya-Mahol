<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
$pdo=db();
$pdo->beginTransaction();
$pdo->prepare('INSERT INTO waste_records(inventory_item_id,quantity,reason,recorded_at) VALUES(?,?,?,?)')->execute([$_POST['inventory_item_id'],$_POST['quantity'],$_POST['reason'],$_POST['recorded_at']]);
$pdo->prepare('UPDATE inventory_items SET quantity=GREATEST(0,quantity-?) WHERE id=?')->execute([$_POST['quantity'],$_POST['inventory_item_id']]);
$pdo->commit();
flash('Waste recorded and stock reduced.');
redirect('/admin/waste.php');
}
$items=db()->query('SELECT * FROM inventory_items')->fetchAll();
$rows=db()->query('SELECT w.*,i.name item FROM waste_records w JOIN inventory_items i ON i.id=w.inventory_item_id ORDER BY w.id DESC')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Waste Management</h1>
<form method="post" class="form wide">
<select name="inventory_item_id">
<?php
foreach($items as $i): ?>
<option value="<?= $i['id'] ?>">
<?= e($i['name']) ?>
</option>
<?php
endforeach;
?>
</select>
<input name="quantity" type="number" step="0.01" placeholder="Quantity">
<input name="reason" placeholder="Expired or damaged reason">
<input name="recorded_at" type="date">
<button class="button">Record Waste</button>
</form>
<div class="table-wrap">
<table>
<tr>
<th>Item</th>
<th>Qty</th>
<th>Reason</th>
<th>Date</th>
</tr>
<?php
foreach($rows as $r): ?>
<tr>
<td>
<?= e($r['item']) ?>
</td>
<td>
<?= e($r['quantity']) ?>
</td>
<td>
<?= e($r['reason']) ?>
</td>
<td>
<?= e($r['recorded_at']) ?>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
