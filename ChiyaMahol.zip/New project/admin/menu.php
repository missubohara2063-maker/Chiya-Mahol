<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
if(isset($_POST['delete'])) db()->prepare('DELETE FROM foods WHERE id=?')->execute([$_POST['id']]);
else {
$id=(int)($_POST['id']??0);
if($id) db()->prepare('UPDATE foods SET category_id=?,name=?,description=?,price=?,discount=?,image_url=?,is_available=? WHERE id=?')->execute([$_POST['category_id'],$_POST['name'],$_POST['description'],$_POST['price'],$_POST['discount'],$_POST['image_url'],isset($_POST['is_available'])?1:0,$id]);
else db()->prepare('INSERT INTO foods(category_id,name,description,price,discount,image_url,is_available) VALUES(?,?,?,?,?,?,?)')->execute([$_POST['category_id'],$_POST['name'],$_POST['description'],$_POST['price'],$_POST['discount'],$_POST['image_url'],isset($_POST['is_available'])?1:0]);
}
flash('Menu updated.');
redirect('/admin/menu.php');
}
$cats=db()->query('SELECT * FROM categories')->fetchAll();
$foods=db()->query('SELECT f.*,c.name category FROM foods f JOIN categories c ON c.id=f.category_id ORDER BY f.id DESC')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Menu Management</h1>
<form method="post" class="form wide">
<select name="category_id">
<?php
foreach($cats as $c): ?>
<option value="<?= $c['id'] ?>">
<?= e($c['name']) ?>
</option>
<?php
endforeach;
?>
</select>
<input name="name" placeholder="Food name" required>
<textarea name="description" placeholder="Description">
</textarea>
<input name="price" type="number" step="0.01" placeholder="Price" required>
<input name="discount" type="number" step="0.01" placeholder="Discount" value="0">
<input name="image_url" placeholder="Food photo URL">
<label>
<input type="checkbox" name="is_available" checked> Available</label>
<button class="button">Add Food</button>
</form>
<div class="table-wrap">
<table>
<tr>
<th>Name</th>
<th>Category</th>
<th>Price</th>
<th>Status</th>
<th>Delete</th>
</tr>
<?php
foreach($foods as $f): ?>
<tr>
<td>
<?= e($f['name']) ?>
</td>
<td>
<?= e($f['category']) ?>
</td>
<td>Rs. <?= number_format((float)$f['price'],2) ?>
</td>
<td>
<?= $f['is_available']?'Available':'Unavailable' ?>
</td>
<td>
<form method="post">
<input type="hidden" name="id" value="<?= $f['id'] ?>">
<button class="ghost small" name="delete" value="1">Delete</button>
</form>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
