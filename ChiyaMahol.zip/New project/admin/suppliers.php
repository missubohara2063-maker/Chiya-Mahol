<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
db()->prepare('INSERT INTO suppliers(name,contact_person,phone,email,address) VALUES(?,?,?,?,?)')->execute([$_POST['name'],$_POST['contact_person'],$_POST['phone'],$_POST['email'],$_POST['address']]);
flash('Supplier added.');
redirect('/admin/suppliers.php');
}
$rows=db()->query('SELECT * FROM suppliers ORDER BY name')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Supplier Management</h1>
<form method="post" class="form wide">
<input name="name" placeholder="Supplier name">
<input name="contact_person" placeholder="Contact person">
<input name="phone" placeholder="Phone">
<input name="email" placeholder="Email">
<input name="address" placeholder="Address">
<button class="button">Add Supplier</button>
</form>
<div class="table-wrap">
<table>
<tr>
<th>Name</th>
<th>Contact</th>
<th>Phone</th>
<th>Email</th>
<th>Address</th>
</tr>
<?php
foreach($rows as $r): ?>
<tr>
<td>
<?= e($r['name']) ?>
</td>
<td>
<?= e($r['contact_person']) ?>
</td>
<td>
<?= e($r['phone']) ?>
</td>
<td>
<?= e($r['email']) ?>
</td>
<td>
<?= e($r['address']) ?>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
