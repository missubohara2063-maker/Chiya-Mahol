<div class="table-wrap">
<table>
<tr>
<th>Name</th>
<th>Phone</th>
<th>Role</th>
<th>Salary</th>
<th>Status</th>
</tr>
<?php
foreach($rows as $r): ?>
<tr>
<td>
<?= e($r['name']) ?>
</td>
<td>
<?= e($r['phone']) ?>
</td>
<td>
<?= e($r['role']) ?>
</td>
<td>
<?= number_format((float)$r['salary'],2) ?>
</td>
<td>
<?= e($r['status']) ?>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
