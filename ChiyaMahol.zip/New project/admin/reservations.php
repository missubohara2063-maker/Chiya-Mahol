<?php
require_once __DIR__ . '/../includes/functions.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    db()->prepare('UPDATE reservations SET status = ? WHERE id = ?')
        ->execute([$_POST['status'], $_POST['id']]);

    $s = db()->prepare('SELECT r.*, u.name, u.email FROM reservations r JOIN users u ON u.id = r.user_id WHERE r.id = ?');
    $s->execute([$_POST['id']]);
    $reservation = $s->fetch();

    if ($reservation) {
        $message = "Your table reservation #{$reservation['id']} is now {$_POST['status']}.";
        notify_user_email((int)$reservation['user_id'], 'Table reservation update', $message);
        notify_admin_email('Table reservation update', "Reservation #{$reservation['id']} for {$reservation['name']} is now {$_POST['status']}.");
    }

    flash('Reservation updated and notification sent.');
    redirect('/admin/reservations.php');
}

$rows = db()->query('SELECT r.*, u.name FROM reservations r JOIN users u ON u.id = r.user_id ORDER BY r.reserved_at DESC')->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<h1>Table Reservations</h1>
<div class="table-wrap">
    <table>
        <tr>
            <th>Customer</th>
            <th>Table</th>
            <th>Guests</th>
            <th>Time</th>
            <th>Status</th>
            <th>Update</th>
        </tr>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td><?= e($r['name']) ?></td>
                <td><?= e($r['table_no']) ?></td>
                <td><?= e($r['guests']) ?></td>
                <td><?= e($r['reserved_at']) ?></td>
                <td><?= e($r['status']) ?></td>
                <td>
                    <form method="post">
                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                        <select name="status">
                            <option <?= $r['status'] === 'pending' ? 'selected' : '' ?>>pending</option>
                            <option <?= $r['status'] === 'confirmed' ? 'selected' : '' ?>>confirmed</option>
                            <option <?= $r['status'] === 'cancelled' ? 'selected' : '' ?>>cancelled</option>
                        </select>
                        <button class="ghost small">Save</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>