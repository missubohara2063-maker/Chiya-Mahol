<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$stats = [
    'orders' => (int)db()->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'today_orders' => (int)db()->query('SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()')->fetchColumn(),
    'sales' => (float)db()->query('SELECT COALESCE(SUM(total), 0) FROM orders WHERE DATE(created_at) = CURDATE()')->fetchColumn(),
    'revenue' => (float)db()->query('SELECT COALESCE(SUM(total), 0) FROM orders')->fetchColumn(),
    'popular' => db()->query('SELECT f.name FROM order_items oi JOIN foods f ON f.id = oi.food_id GROUP BY f.id ORDER BY SUM(oi.quantity) DESC LIMIT 1')->fetchColumn() ?: 'No sales yet'
];

$statusRows = db()->query('SELECT status, COUNT(*) total FROM orders GROUP BY status')->fetchAll();
$statusCounts = ['received' => 0, 'preparing' => 0, 'out for delivery' => 0, 'delivered' => 0, 'cancelled' => 0];
foreach ($statusRows as $row) {
    $statusCounts[$row['status']] = (int)$row['total'];
}

$salesRows = db()->query("SELECT DATE(created_at) day, COALESCE(SUM(total), 0) total FROM orders WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) GROUP BY DATE(created_at) ORDER BY day")->fetchAll();
$salesValues = array_map(fn($row) => (float)$row['total'], $salesRows);
$maxSales = max(array_merge([1], $salesValues));
$recentOrders = db()->query('SELECT o.*, u.name customer FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC LIMIT 6')->fetchAll();
$lowStock = db()->query('SELECT * FROM inventory_items WHERE quantity <= low_stock_level ORDER BY quantity ASC LIMIT 5')->fetchAll();
$pendingReservations = (int)db()->query("SELECT COUNT(*) FROM reservations WHERE status = 'pending'")->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>
<section class="dashboard-shell admin-dashboard">
    <div class="dashboard-hero-card">
        <div>
            <p class="eyebrow">Restaurant Control Center</p>
            <h1>Welcome back, Admin</h1>
            <p>Track orders, revenue, stock alerts, deliveries, and reservations from one clear workspace.</p>
        </div>
        <div class="hero-metric">
            <span>Today</span>
            <strong>Rs. <?= number_format($stats['sales'], 2) ?></strong>
            <small><?= $stats['today_orders'] ?> orders received</small>
        </div>
    </div>

    <section class="metric-grid">
        <article class="metric-card accent-a">
            <span>Total Orders</span>
            <strong><?= $stats['orders'] ?></strong>
            <small>All-time customer orders</small>
        </article>
        <article class="metric-card accent-b">
            <span>Daily Sales</span>
            <strong>Rs. <?= number_format($stats['sales'], 0) ?></strong>
            <small>Revenue collected today</small>
        </article>
        <article class="metric-card accent-c">
            <span>Total Revenue</span>
            <strong>Rs. <?= number_format($stats['revenue'], 0) ?></strong>
            <small>Complete sales value</small>
        </article>
        <article class="metric-card accent-d">
            <span>Popular Item</span>
            <strong><?= e($stats['popular']) ?></strong>
            <small>Best performing menu item</small>
        </article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel wide-panel">
            <div class="panel-head">
                <div>
                    <p class="eyebrow">Sales Trend</p>
                    <h2>Last 7 Days</h2>
                </div>
                <a class="ghost small" href="reports.php">View Reports</a>
            </div>
            <div class="bar-chart" aria-label="Sales chart">
                <?php foreach ($salesRows as $row): ?>
                    <?php $height = max(8, ((float)$row['total'] / $maxSales) * 100); ?>
                    <div class="bar-item">
                        <div class="bar-track"><span style="height: <?= $height ?>%"></span></div>
                        <small><?= date('D', strtotime($row['day'])) ?></small>
                    </div>
                <?php endforeach; ?>
                <?php if (!$salesRows): ?>
                    <p class="muted">Sales chart will appear after orders are placed.</p>
                <?php endif; ?>
            </div>
        </article>

        <article class="dashboard-panel">
            <div class="panel-head">
                <div>
                    <p class="eyebrow">Order Flow</p>
                    <h2>Status</h2>
                </div>
            </div>
            <div class="status-stack">
                <?php foreach ($statusCounts as $label => $count): ?>
                    <div class="status-row">
                        <span><?= e(ucwords($label)) ?></span>
                        <strong><?= $count ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        </article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel">
            <div class="panel-head">
                <div>
                    <p class="eyebrow">Quick Actions</p>
                    <h2>Manage</h2>
                </div>
            </div>
            <nav class="action-grid">
                <a href="menu.php"><span>Menu</span><small>Add or edit food</small></a>
                <a href="deliveries.php"><span>Deliveries</span><small>Assign staff</small></a>
                <a href="inventory.php"><span>Inventory</span><small><?= low_stock_count() ?> low stock</small></a>
                <a href="reservations.php"><span>Reservations</span><small><?= $pendingReservations ?> pending</small></a>
                <a href="employees.php"><span>Employees</span><small>Roles and staff</small></a>
                <a href="reports.php"><span>Reports</span><small>Sales analytics</small></a>
            </nav>
        </article>

        <article class="dashboard-panel wide-panel">
            <div class="panel-head">
                <div>
                    <p class="eyebrow">Recent Activity</p>
                    <h2>Latest Orders</h2>
                </div>
            </div>
            <div class="mini-table">
                <?php foreach ($recentOrders as $order): ?>
                    <div class="mini-row">
                        <span>#<?= $order['id'] ?> &middot; <?= e($order['customer']) ?></span>
                        <span><?= e($order['status']) ?></span><small><?= e(order_items_label((int)$order['id'])) ?></small>
                        <strong>Rs. <?= number_format((float)$order['total'], 0) ?></strong>
                    </div>
                <?php endforeach; ?>
                <?php if (!$recentOrders): ?>
                    <p class="muted">No orders yet.</p>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel wide-panel">
            <div class="panel-head">
                <div>
                    <p class="eyebrow">Stock Watch</p>
                    <h2>Low Stock Alerts</h2>
                </div>
                <a class="ghost small" href="inventory.php">Open Inventory</a>
            </div>
            <div class="stock-list">
                <?php foreach ($lowStock as $item): ?>
                    <div class="stock-item">
                        <div>
                            <strong><?= e($item['name']) ?></strong>
                            <span><?= e($item['quantity']) ?> <?= e($item['unit']) ?> left</span>
                        </div>
                        <em>Reorder</em>
                    </div>
                <?php endforeach; ?>
                <?php if (!$lowStock): ?>
                    <p class="muted">All stock levels look good.</p>
                <?php endif; ?>
            </div>
        </article>
    </section>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>


