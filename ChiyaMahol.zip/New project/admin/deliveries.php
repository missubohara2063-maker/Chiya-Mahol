<?php
require_once __DIR__ . '/../includes/functions.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    db()->prepare('INSERT INTO deliveries(order_id, employee_id, status, tracking_note) VALUES(?, ?, ?, ?)')
        ->execute([$_POST['order_id'], $_POST['employee_id'], $_POST['status'], $_POST['tracking_note']]);

    db()->prepare('UPDATE orders SET status = ? WHERE id = ?')
        ->execute([$_POST['order_status'], $_POST['order_id']]);

    notify_order_status((int)$_POST['order_id'], $_POST['order_status']);

    $stockMessage = '';
    if (in_array($_POST['order_status'], ['preparing', 'out for delivery', 'delivered'], true)) {
        $stockResult = reduce_order_inventory_when_preparing((int)$_POST['order_id']);
        $stockMessage = ' ' . $stockResult['message'];
    }

    flash('Delivery assigned, status updated, and notification sent.' . $stockMessage);
    redirect('/admin/deliveries.php');
}

$orders = db()->query('SELECT * FROM orders ORDER BY id DESC')->fetchAll();
$staff = db()->query("SELECT * FROM employees WHERE role = 'delivery staff' AND status = 'active'")->fetchAll();
$rows = db()->query('SELECT d.*, e.name staff, o.order_location FROM deliveries d JOIN employees e ON e.id = d.employee_id JOIN orders o ON o.id = d.order_id ORDER BY d.id DESC')->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<h1>Delivery Management</h1>
<form method="post" class="form wide">
    <select name="order_id">
        <?php foreach ($orders as $o): ?>
            <option value="<?= $o['id'] ?>">Order #<?= $o['id'] ?> - <?= e(order_items_label((int)$o['id'])) ?> - <?= e($o['status']) ?> - <?= e($o['order_location'] ?? 'No location') ?></option>
        <?php endforeach; ?>
    </select>

    <select name="employee_id">
        <?php foreach ($staff as $s): ?>
            <option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option>
        <?php endforeach; ?>
    </select>

    <select name="status">
        <option>assigned</option>
        <option>picked up</option>
        <option>delivered</option>
    </select>

    <select name="order_status">
        <option>preparing</option>
        <option>out for delivery</option>
        <option>delivered</option>
    </select>

    <input name="tracking_note" placeholder="Tracking note">
    <button class="button">Assign</button>
</form>

<div class="table-wrap">
    <table>
        <tr>
            <th>Order</th>
            <th>Staff</th>
            <th>Status</th>
            <th>Foods Ordered</th>
            <th>Location</th>
            <th>Note</th>
        </tr>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td>#<?= $r['order_id'] ?></td>
                <td><?= e($r['staff']) ?></td>
                <td><?= e($r['status']) ?></td>
                <td><?= e(order_items_label((int)$r['order_id'])) ?></td>
                <td><?= e($r['order_location'] ?? 'Not provided') ?></td>
                <td><?= e($r['tracking_note']) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>



