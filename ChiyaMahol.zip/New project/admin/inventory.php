<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
db()->prepare('INSERT INTO inventory_items(name,unit,quantity,low_stock_level,expiry_date) VALUES(?,?,?,?,?)')->execute([$_POST['name'],$_POST['unit'],$_POST['quantity'],$_POST['low_stock_level'],$_POST['expiry_date']?:null]);
flash('Inventory item added.');
redirect('/admin/inventory.php');
}
$rows=db()->query('SELECT * FROM inventory_items ORDER BY name')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Stock Management</h1>
<form method="post" class="form wide">
<input name="name" placeholder="Raw material">
<select name="unit">
<option>kg</option>
<option>liter</option>
<option>packet</option>
<option>piece</option>
</select>
<input name="quantity" type="number" step="0.01" placeholder="Available quantity">
<input name="low_stock_level" type="number" step="0.01" placeholder="Low stock level">
<input name="expiry_date" type="date">
<button class="button">Add Stock</button>
</form>
<div class="table-wrap">
<table>
<tr>
<th>Item</th>
<th>Qty</th>
<th>Unit</th>
<th>Low Alert</th>
<th>Expiry</th>
</tr>
<?php
foreach($rows as $r): ?>
<tr class="<?= $r['quantity'] <= $r['low_stock_level'] ? 'warn-row' : '' ?>">
<td>
<?= e($r['name']) ?>
</td>
<td>
<?= e($r['quantity']) ?>
</td>
<td>
<?= e($r['unit']) ?>
</td>
<td>
<?= $r['quantity'] <= $r['low_stock_level'] ? 'Reorder needed' : 'OK' ?>
</td>
<td>
<?= e($r['expiry_date'] ?? '') ?>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
