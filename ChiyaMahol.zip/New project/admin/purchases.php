<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
$pdo=db();
$pdo->beginTransaction();
$pdo->prepare('INSERT INTO purchases(supplier_id,inventory_item_id,quantity,unit_price,bill_no,purchased_at) VALUES(?,?,?,?,?,?)')->execute([$_POST['supplier_id'],$_POST['inventory_item_id'],$_POST['quantity'],$_POST['unit_price'],$_POST['bill_no'],$_POST['purchased_at']]);
$pdo->prepare('UPDATE inventory_items SET quantity=quantity+? WHERE id=?')->execute([$_POST['quantity'],$_POST['inventory_item_id']]);
$pdo->commit();
flash('Purchase recorded and stock increased.');
redirect('/admin/purchases.php');
}
$sup=db()->query('SELECT * FROM suppliers')->fetchAll();
$items=db()->query('SELECT * FROM inventory_items')->fetchAll();
$rows=db()->query('SELECT p.*,s.name supplier,i.name item FROM purchases p JOIN suppliers s ON s.id=p.supplier_id JOIN inventory_items i ON i.id=p.inventory_item_id ORDER BY p.id DESC')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Purchase Management</h1>
<form method="post" class="form wide">
<select name="supplier_id">
<?php
foreach($sup as $s): ?>
<option value="<?= $s['id'] ?>">
<?= e($s['name']) ?>
</option>
<?php
endforeach;
?>
</select>
<select name="inventory_item_id">
<?php
foreach($items as $i): ?>
<option value="<?= $i['id'] ?>">
<?= e($i['name']) ?>
</option>
<?php
endforeach;
?>
</select>
<input name="quantity" type="number" step="0.01" placeholder="Quantity">
<input name="unit_price" type="number" step="0.01" placeholder="Unit price">
<input name="bill_no" placeholder="Bill number">
<input name="purchased_at" type="date">
<button class="button">Record Purchase</button>
</form>
<div class="table-wrap">
<table>
<tr>
<th>Bill</th>
<th>Supplier</th>
<th>Item</th>
<th>Qty</th>
<th>Total</th>
<th>Date</th>
</tr>
<?php
foreach($rows as $r): ?>
<tr>
<td>
<?= e($r['bill_no']) ?>
</td>
<td>
<?= e($r['supplier']) ?>
</td>
<td>
<?= e($r['item']) ?>
</td>
<td>
<?= e($r['quantity']) ?>
</td>
<td>Rs. <?= number_format((float)$r['quantity']*(float)$r['unit_price'],2) ?>
</td>
<td>
<?= e($r['purchased_at']) ?>
</td>
</tr>
<?php
endforeach;
?>
</table>
</div>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
