<?php
require_once __DIR__.'/../includes/functions.php';
require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
db()->prepare('INSERT INTO employees(name,phone,role,salary,status) VALUES(?,?,?,?,?)')->execute([$_POST['name'],$_POST['phone'],$_POST['role'],$_POST['salary'],$_POST['status']]);
flash('Employee added.');
redirect('/admin/employees.php');
}
$rows=db()->query('SELECT * FROM employees ORDER BY id DESC')->fetchAll();
require_once __DIR__.'/../includes/header.php';
?>
<h1>Employee Management</h1>
<form method="post" class="form wide">
<input name="name" placeholder="Name">
<input name="phone" placeholder="Phone">
<select name="role">
<option>chef</option>
<option>cashier</option>
<option>delivery staff</option>
<option>manager</option>
</select>
<input name="salary" type="number" step="0.01" placeholder="Salary">
<select name="status">
<option>active</option>
<option>inactive</option>
</select>
<button class="button">Add Employee</button>
</form>
<?php
include __DIR__.'/table_employees.php';
?>
<?php
require_once __DIR__.'/../includes/footer.php';
?>
