# Chiya Mahol - Food Ordering and Inventory Management System

PHP + MySQL college project for customer ordering, restaurant admin, inventory, reports, delivery, reviews, and table reservations.

## Setup

1. Copy this folder into XAMPP `htdocs`.
2. Open phpMyAdmin and import `database/chiya_mahol.sql`.
3. Check database settings in `config/config.php`.
4. Visit `http://localhost/New%20project/public/index.php`.
5. Admin panel: `http://localhost/New%20project/admin/index.php`.

## Default Login

Admin:
- Email: `admin@chiyamahol.test`
- Password: `admin123`

Customer:
- Email: `aasha@example.com`
- Password: `customer123`

## Included Features

Customer: registration/login, password recovery demo, social login demo, menu categories, search/filter, images/prices/availability, cart, coupons, tax/delivery calculation, dine-in/takeaway/delivery, scheduled orders, instructions, COD/wallet/card/QR payment options, order tracking, notifications, reviews, profile, order history, saved address, favorites, table reservation.

Admin/restaurant: dashboard, total orders, daily sales, revenue, popular items, menu add/delete, employee roles, delivery assignment/status, stock management, automatic stock reduction from recipes, low stock alert, supplier management, purchases, bill records, waste management, expiry tracking, sales report, inventory report, profit/loss, customer analytics.

## Notes for Viva

- `orders` and `order_items` store customer orders.
- `recipes` maps food items to inventory ingredients.
- When admin changes an order to preparing, recipe quantities reduce raw inventory automatically once per order.
- `purchases` increase inventory stock, while `waste_records` reduce stock.
- Reports are generated with SQL aggregation queries in `admin/reports.php`.

