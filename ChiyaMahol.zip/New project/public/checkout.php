<?php
require_once __DIR__ . '/../includes/functions.php';

$user = require_login();
$savedStmt = db()->prepare('SELECT * FROM addresses WHERE user_id = ? ORDER BY id DESC');
$savedStmt->execute([$user['id']]);
$savedAddresses = $savedStmt->fetchAll();
$items = cart_items();

if (!$items) {
    flash('Your cart is empty.');
    redirect('/public/menu.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scheduledAt = trim($_POST['scheduled_at'] ?? '');
    $orderLocation = trim($_POST['order_location'] ?? '');

    if ($scheduledAt !== '' && strtotime($scheduledAt) < time()) {
        flash('Please choose a future date and time for scheduled orders.');
        redirect('/public/checkout.php');
    }

    if ($orderLocation === '') {
        flash('Please enter your location before placing the order.');
        redirect('/public/checkout.php');
    }

    $sum = cart_summary($_SESSION['coupon'] ?? null);
    $pdo = db();
    $pdo->beginTransaction();

    $s = $pdo->prepare('INSERT INTO orders(user_id, order_type, payment_method, order_location, subtotal, discount, tax, delivery_charge, total, scheduled_at, special_instructions, status) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "received")');
    $s->execute([
        $user['id'],
        $_POST['order_type'],
        $_POST['payment_method'],
        $orderLocation,
        $sum['subtotal'],
        $sum['discount'],
        $sum['tax'],
        $sum['delivery'],
        $sum['total'],
        $scheduledAt ?: null,
        trim($_POST['special_instructions'])
    ]);

    $oid = (int)$pdo->lastInsertId();

    foreach ($items as $item) {
        $pdo->prepare('INSERT INTO order_items(order_id, food_id, quantity, price) VALUES(?, ?, ?, ?)')
            ->execute([$oid, $item['id'], $item['quantity'], $item['price']]);

    }

    $pdo->commit();
    notify_order_status($oid, 'received');

    unset($_SESSION['cart'], $_SESSION['coupon']);
    flash('Order placed successfully. Notification sent to customer and admin.');
    redirect('/public/order_tracking.php?id=' . $oid);
}

$minSchedule = date('Y-m-d\TH:i');
require_once __DIR__ . '/../includes/header.php';
?>
<h1>Checkout</h1>
<form method="post" class="form wide">
    <label>
        Order Type
        <select name="order_type" required>
            <option>dine-in</option>
            <option>takeaway</option>
            <option>delivery</option>
        </select>
    </label>

    <label>
        Payment
        <select name="payment_method" required>
            <option>cash on delivery</option>
            <option>digital wallet</option>
            <option>card payment</option>
            <option>qr payment</option>
        </select>
    </label>

        <label>
        Saved Location
        <select name="saved_location" onchange="if(this.value){document.querySelector('[name=order_location]').value=this.value;}">
            <option value="">Choose saved location</option>
            <?php foreach ($savedAddresses as $address): ?>
                <option value="<?= e($address['address']) ?>"><?= e($address['label']) ?> - <?= e($address['address']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>

    <label>
        Your Location
        <input name="order_location" placeholder="Enter delivery/pickup location" required>
    </label>

    <label>
        Schedule for later
        <input type="datetime-local" name="scheduled_at" min="<?= e($minSchedule) ?>">
    </label>

    <textarea name="special_instructions" placeholder="Special instructions for food"></textarea>
    <button class="button">Place Order</button>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>


