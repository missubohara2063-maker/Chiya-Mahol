<?php
require_once __DIR__ . '/../includes/functions.php';

$u = require_login();
$tables = [
    'T1' => ['shape' => 'round', 'chairs' => 6, 'area' => 'Main hall'],
    'T2' => ['shape' => 'round', 'chairs' => 4, 'area' => 'Window side'],
    'T3' => ['shape' => 'square', 'chairs' => 2, 'area' => 'Quiet corner'],
    'T4' => ['shape' => 'square', 'chairs' => 2, 'area' => 'Middle row'],
    'T5' => ['shape' => 'square', 'chairs' => 2, 'area' => 'Middle row'],
    'T6' => ['shape' => 'round', 'chairs' => 5, 'area' => 'Upper right'],
    'T7' => ['shape' => 'round', 'chairs' => 5, 'area' => 'Upper left'],
];

$bookedStmt = db()->query("SELECT table_no FROM reservations WHERE status IN ('pending', 'confirmed') AND reserved_at >= NOW()");
$bookedTables = [];
foreach ($bookedStmt->fetchAll() as $row) {
    foreach (explode(',', (string)$row['table_no']) as $bookedTable) {
        $bookedTable = trim($bookedTable);
        if ($bookedTable !== '') {
            $bookedTables[$bookedTable] = true;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedTables = array_filter(array_map('trim', explode(',', $_POST['table_no'] ?? '')));
    $reservedAt = trim($_POST['reserved_at'] ?? '');

    if (!$selectedTables) {
        flash('Please select at least one table from the floor plan.');
        redirect('/public/reservation.php');
    }

    $capacity = 0;
    foreach ($selectedTables as $tableNo) {
        if (!isset($tables[$tableNo])) {
            flash('Invalid table selection. Please choose again.');
            redirect('/public/reservation.php');
        }

        if (isset($bookedTables[$tableNo])) {
            flash("Table $tableNo is already booked. Please choose another table.");
            redirect('/public/reservation.php');
        }

        $capacity += (int)$tables[$tableNo]['chairs'];
    }

    $reservationTimestamp = strtotime($reservedAt);
    $reservationTime = $reservationTimestamp ? date('H:i', $reservationTimestamp) : '';

    if ($reservedAt === '' || !$reservationTimestamp || $reservationTimestamp < time()) {
        flash('Please choose a future reservation date and time.');
        redirect('/public/reservation.php');
    }

    if ($reservationTime < '08:00' || $reservationTime > '21:00') {
        flash('Table reservations are available only during cafe opening hours: 8:00 AM to 9:00 PM.');
        redirect('/public/reservation.php');
    }

    $tableList = implode(',', $selectedTables);
    $s = db()->prepare('INSERT INTO reservations(user_id, table_no, guests, reserved_at, status) VALUES(?, ?, ?, ?, "pending")');
    $s->execute([$u['id'], $tableList, $capacity, $reservedAt]);

    $reservationId = (int)db()->lastInsertId();
    $message = "Table reservation #$reservationId requested for table(s) $tableList on $reservedAt. Total seating capacity: $capacity.";

    notify_user_email((int)$u['id'], 'Table reservation requested', $message);
    notify_admin_email('New table reservation', $message . " Customer: {$u['name']} ({$u['email']}).");

    flash('Table reservation requested. Notification sent to customer and admin.');
    redirect('/public/profile.php');
}

$minReservation = date('Y-m-d\TH:i');
require_once __DIR__ . '/../includes/header.php';
?>
<section class="reservation-shell">
    <div class="reservation-head premium-reservation-head">
        <div>
            <p class="eyebrow">Movie-ticket style booking</p>
            <h1>Select Your Table</h1>
            <p>Tap one or more available tables from the Chiya Mahol floor plan. Yellow tables are selected, grey tables are already booked.</p>
        </div>
        <div class="reservation-legend">
            <span><i class="legend-dot available"></i>Available</span>
            <span><i class="legend-dot selected"></i>Selected</span>
            <span><i class="legend-dot booked"></i>Booked</span>
        </div>
    </div>

    <div class="reservation-layout premium-reservation-layout">
        <div class="floor-plan premium-floor-plan" aria-label="Chiya Mahol table layout">
            <div class="floor-zone zone-top">Upper Seating</div>
            <div class="floor-zone zone-bottom">Main Seating</div>
            <div class="floor-line main-divider"></div>
            <?php foreach ($tables as $tableNo => $table): ?>
                <?php $isBooked = isset($bookedTables[$tableNo]); ?>
                <button
                    type="button"
                    class="table-seat table-<?= e(strtolower($tableNo)) ?> <?= e($table['shape']) ?> <?= $isBooked ? 'is-booked' : '' ?>"
                    data-table="<?= e($tableNo) ?>"
                    data-chairs="<?= e((string)$table['chairs']) ?>"
                    data-area="<?= e($table['area']) ?>"
                    <?= $isBooked ? 'disabled' : '' ?>
                >
                    <span><?= e($tableNo) ?></span>
                    <small><?= e((string)$table['chairs']) ?> seats</small>
                    <?php for ($i = 1; $i <= $table['chairs']; $i++): ?>
                        <i class="chair chair-<?= $i ?>"></i>
                    <?php endfor; ?>
                </button>
            <?php endforeach; ?>
        </div>

        <aside class="reservation-card premium-reservation-card">
            <h2>Booking Details</h2>
            <p class="selected-table-copy">Select one or more tables from the floor plan.</p>
            <div class="selected-table-list"></div>
            <form method="post" class="form reservation-form">
                <input type="hidden" name="table_no" id="selectedTable" required>
                <label>
                    Date and Time
                    <input type="datetime-local" name="reserved_at" min="<?= e($minReservation) ?>" required>
                    <small class="form-hint">Cafe opening time: 8:00 AM to 9:00 PM.</small>
                </label>
                <button class="button" type="submit">Reserve Selected Tables</button>
            </form>
        </aside>
    </div>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

