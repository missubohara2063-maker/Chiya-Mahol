<?php
require_once __DIR__ . '/../includes/functions.php';

$foods = db()->query('SELECT * FROM foods WHERE is_available = 1 ORDER BY id LIMIT 6')->fetchAll();
$totalOrders = (int)db()->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$totalUsers = (int)db()->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
require_once __DIR__ . '/../includes/header.php';
?>
<section class="home-hero">
    <div class="hero-bg-food food-dot dot-one"></div>
    <div class="hero-bg-food food-dot dot-two"></div>
    <div class="hero-bg-food leaf-dot dot-three"></div>

    <div class="phone-stage" aria-hidden="true">
        <div class="floating-badge order-badge">
            <span>Orders</span>
            <strong><?= number_format(max($totalOrders, 12)) ?>+</strong>
        </div>
        <div class="floating-badge review-badge">
            <span>Reviews</span>
            <strong>4.8+</strong>
        </div>
        <div class="floating-badge user-badge">
            <span>Users</span>
            <strong><?= number_format(max($totalUsers, 4)) ?>+</strong>
        </div>

        <div class="phone-mockup">
            <div class="phone-notch"></div>
            <div class="phone-screen">
                <div class="phone-top">
                    <small>Chiya Mahol</small>
                    <strong>Fresh Near You</strong>
                </div>
                <div class="phone-search">Search tea, momo, pizza...</div>
                <div class="phone-banner">
                    <span>Today Special</span>
                    <strong>30% Off Snacks</strong>
                </div>
                <div class="phone-food-grid">
                    <?php foreach ($foods as $food): ?>
                        <div>
                            <img src="<?= e($food['image_url']) ?>" alt="">
                            <span><?= e($food['name']) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="home-hero-copy">
        <p class="eyebrow">Online food ordering and inventory management</p>
        <h1>Nepal's Cozy Food Ordering Experience</h1>
        <p>Chiya Mahol brings tea, snacks, meals, reservations, delivery tracking, and smart restaurant inventory into one smooth college-project system.</p>
        <div class="home-cta-row">
            <a class="button hero-order-btn" href="<?= BASE_URL ?>/public/menu.php">Order Now <span>→</span></a>
            <a class="ghost hero-secondary-btn" href="<?= BASE_URL ?>/public/reservation.php">Reserve Table</a>
        </div>
        <div class="hero-mini-stats">
            <div><strong>Fast</strong><span>Ordering</span></div>
            <div><strong>Live</strong><span>Tracking</span></div>
            <div><strong>Smart</strong><span>Inventory</span></div>
        </div>
    </div>
</section>


<section class="cafe-story-section">
    <div class="cafe-photo-panel">
        <img src="<?= BASE_URL ?>/assets/images/home.jpeg" alt="Chiya Mahol cafe">
        <div class="cafe-photo-badge">
            <strong>Chiya Mahol</strong>
            <span>Kwalakhu Road, Lalitpur</span>
        </div>
    </div>

    <div class="cafe-story-copy">
        <p class="eyebrow">About the Cafe</p>
        <h2>A cozy place for chiya, snacks, and good moments.</h2>
        <p>
            Chiya Mahol is designed as a warm local cafe experience where customers can enjoy tea,
            snacks, meals, table reservations, and easy food ordering. This system connects the customer
            side with restaurant operations like delivery, order tracking, inventory, reports, and staff management.
        </p>

        <div class="cafe-info-grid">
            <article><strong>Fresh Menu</strong><span>Tea, momo, pizza, burgers, snacks, and drinks.</span></article>
            <article><strong>Easy Access</strong><span>Located at Kwalakhu Road, Lalitpur.</span></article>
            <article><strong>Smart Service</strong><span>Online ordering, reservations, tracking, and inventory control.</span></article>
        </div>

        <div class="cafe-link-row">
            <a class="button" href="https://www.google.com/maps/dir//M8GF%2B9WH+Chiya+Mahol,+Kwalakhu+Rd,+Lalitpur+44700/@27.6764585,85.3250387,16z/data=!4m16!1m7!3m6!1s0x39eb190012390f41:0xe18312043514dcb2!2sChiya+Mahol!8m2!3d27.6759135!4d85.3248827!16s%2Fg%2F11wtw1r7xv!4m7!1m0!1m5!1m1!1s0x39eb190012390f41:0xe18312043514dcb2!2m2!1d85.3248852!2d27.675909?entry=ttu&g_ep=EgoyMDI2MDUxMy4wIKXMDSoASAFQAw%3D%3D" target="_blank" rel="noopener"><span class="link-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 21s7-5.2 7-11a7 7 0 0 0-14 0c0 5.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6"/></svg></span><span>Location</span></a>
            <a class="ghost" href="https://www.facebook.com/profile.php?id=61573846449486" target="_blank" rel="noopener"><span class="link-icon facebook-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M15 8h2.2V4.2c-.4-.1-1.7-.2-3.2-.2-3.2 0-5.3 1.9-5.3 5.5V12H5.2v4.3h3.5V24H13v-7.7h3.4L17 12h-4V9.9c0-1.2.3-1.9 2-1.9Z"/></svg></span><span>Facebook</span></a>
        </div>
    </div>
</section>
<section class="home-feature-strip">
    <article>
        <span class="feature-orb">1</span>
        <h3>Order Easily</h3>
        <p>Choose dine-in, takeaway, delivery, schedule time, and add food instructions.</p>
    </article>
    <article>
        <span class="feature-orb">2</span>
        <h3>Track Status</h3>
        <p>Follow your order from received to preparing, out for delivery, and delivered.</p>
    </article>
    <article>
        <span class="feature-orb">3</span>
        <h3>Manage Stock</h3>
        <p>Admin can monitor sales, staff, suppliers, purchases, waste, and low stock alerts.</p>
    </article>
</section>
<section class="home-info-footer" aria-label="Chiya Mahol information">
    <div class="home-info-grid compact-home-info-grid">
        <div class="home-info-brand">
            <img src="<?= BASE_URL ?>/assets/images/brand-logo-new.png?v=18" alt="Chiya Mahol logo">
            <p><strong>Company Name:</strong> Chiya Mahol Cafe</p>
            <p><strong>Project:</strong> Food Ordering and Inventory Management System</p>
            <p><strong>Opening Hours:</strong> 8:00 AM to 9:00 PM</p>
            <p><strong>Location:</strong> Kwalakhu Road, Lalitpur 44700, Nepal</p>
            <p><strong>Support Email:</strong> missubohara2063@gmail.com</p>

            <div class="home-social-row" aria-label="Social links">
                <a href="https://www.facebook.com/profile.php?id=61573846449486" target="_blank" rel="noopener" aria-label="Facebook">
                    <svg viewBox="0 0 24 24"><path d="M15 8h2.2V4.2c-.4-.1-1.7-.2-3.2-.2-3.2 0-5.3 1.9-5.3 5.5V12H5.2v4.3h3.5V24H13v-7.7h3.4L17 12h-4V9.9c0-1.2.3-1.9 2-1.9Z"/></svg>
                </a>
                <a href="https://www.instagram.com/chiya_mahol/" target="_blank" aria-label="Instagram">
                    <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/></svg>
                </a>
            </div>
        </div>

        <div class="home-info-column">
            <h3>Quick Links</h3>
            <a href="<?= BASE_URL ?>/public/index.php">About us</a>
            <a href="<?= BASE_URL ?>/public/menu.php">Menu</a>
            <a href="<?= BASE_URL ?>/public/reservation.php">Reservation</a>
            <a href="<?= BASE_URL ?>/auth/login.php">Login</a>
        </div>

        <div class="home-info-column contact-column">
            <h3>Contact Us</h3>
            <p><span class="mini-contact-icon"><svg viewBox="0 0 24 24"><path d="M12 21s7-5.2 7-11a7 7 0 0 0-14 0c0 5.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6"/></svg></span>Kwalakhu Road, Lalitpur 44700, Nepal</p>
            <p><span class="mini-contact-icon"><svg viewBox="0 0 24 24"><path d="M4 6h16v12H4z"/><path d="m4 7 8 6 8-6"/></svg></span>missubohara2063@gmail.com</p>
            <p><span class="mini-contact-icon"><svg viewBox="0 0 24 24"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.7 19.7 0 0 1-8.6-3.1 19.1 19.1 0 0 1-5.9-5.9A19.7 19.7 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.7.6 2.5a2 2 0 0 1-.4 2.1L8 9.6a16 16 0 0 0 6.4 6.4l1.3-1.3a2 2 0 0 1 2.1-.4c.8.3 1.6.5 2.5.6a2 2 0 0 1 1.7 2Z"/></svg></span>+977 9813104240</p>
        </div>
    </div>

    <p class="home-info-rights">All Right Reserved By Chiya Mahol</p>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>




