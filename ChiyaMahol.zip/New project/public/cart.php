<?php
require_once __DIR__.'/../includes/functions.php';
require_login();
if($_SERVER['REQUEST_METHOD']==='POST'){
if(isset($_POST['remove'])) unset($_SESSION['cart'][(int)$_POST['food_id']]);
else {
foreach($_POST['qty']??[] as $id=>$qty){
$qty=max(0,(int)$qty);
if($qty===0) unset($_SESSION['cart'][$id]);
else $_SESSION['cart'][$id]=$qty;
}
$_SESSION['coupon']=trim($_POST['coupon']??'');
}
flash('Cart updated.');
redirect('/public/cart.php');
}
$items=cart_items();
$sum=cart_summary($_SESSION['coupon']??null);
require_once __DIR__.'/../includes/header.php';
?>
<h1>Your Cart</h1>
<form method="post">
<div class="table-wrap">
<table>
<thead>
<tr>
<th>Food</th>
<th>Price</th>
<th>Qty</th>
<th>Total</th>
<th>
</th>
</tr>
</thead>
<tbody>
<?php
foreach($items as $i): ?>
<tr>
<td>
<?= e($i['name']) ?>
</td>
<td>Rs. <?= number_format((float)$i['price'],2) ?>
</td>
<td>
<input class="qty" type="number" name="qty[<?= $i['id'] ?>
]" value="<?= $i['quantity'] ?>" min="0">
</td>
<td>Rs. <?= number_format((float)$i['line_total'],2) ?>
</td>
<td>
<button class="ghost small" name="remove" value="1" onclick="this.form.food_id.value='<?= $i['id'] ?>
'">Remove</button>
</td>
</tr>
<?php
endforeach;
?>
</tbody>
</table>
</div>
<input type="hidden" name="food_id">
<div class="summary">
<input name="coupon" value="<?= e($_SESSION['coupon']??'') ?>" placeholder="Coupon code e.g. CHIYA10">
<p>Subtotal: Rs. <?= number_format($sum['subtotal'],2) ?>
</p>
<p>Discount: Rs. <?= number_format($sum['discount'],2) ?>
</p>
<p>Tax 13%: Rs. <?= number_format($sum['tax'],2) ?>
</p>
<p>Delivery: Rs. <?= number_format($sum['delivery'],2) ?>
</p>
<h3>Total: Rs. <?= number_format($sum['total'],2) ?>
</h3>
<button class="button">Update Cart</button>
<a class="button" href="<?= BASE_URL ?>/public/checkout.php">Checkout</a>
</div>
</form>
<?php
require_once __DIR__.'/../includes/footer.php';
?>

