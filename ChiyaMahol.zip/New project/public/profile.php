<?php
require_once __DIR__ . '/../includes/functions.php';

ensure_email_verification_columns();
$u = require_login();

if ($u['role'] === 'admin') {
    redirect('/admin/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_image'])) {
    if ($_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $mime = mime_content_type($_FILES['profile_image']['tmp_name']);

        if (!isset($allowed[$mime])) {
            flash('Please upload a JPG, PNG, or WEBP image.');
            redirect('/public/profile.php');
        }

        $uploadDir = __DIR__ . '/../assets/uploads/profiles';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileName = 'profile_' . $u['id'] . '_' . time() . '.' . $allowed[$mime];
        $target = $uploadDir . '/' . $fileName;

        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target)) {
            $relativePath = 'assets/uploads/profiles/' . $fileName;
            db()->prepare('UPDATE users SET profile_image = ? WHERE id = ?')->execute([$relativePath, $u['id']]);
            flash('Profile picture updated.');
            redirect('/public/profile.php');
        }
    }

    flash('Profile picture upload failed. Please try again.');
    redirect('/public/profile.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_location'])) {
    $label = trim($_POST['label']);
    $address = trim($_POST['address']);

    if ($label === '' || $address === '') {
        flash('Please enter both location label and address.');
        redirect('/public/profile.php');
    }

    db()->prepare('INSERT INTO addresses(user_id, label, address) VALUES(?, ?, ?)')->execute([$u['id'], $label, $address]);
    flash('Location saved.');
    redirect('/public/profile.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_location'])) {
    db()->prepare('DELETE FROM addresses WHERE id = ? AND user_id = ?')->execute([(int)$_POST['address_id'], $u['id']]);
    flash('Location removed.');
    redirect('/public/profile.php');
}

$u = require_login();
$ordersStmt = db()->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$ordersStmt->execute([$u['id']]);
$orders = $ordersStmt->fetchAll();
$addr = db()->prepare('SELECT * FROM addresses WHERE user_id = ? ORDER BY id DESC');
$addr->execute([$u['id']]);
$addresses = $addr->fetchAll();
$fav = db()->prepare('SELECT f.* FROM favorites fav JOIN foods f ON f.id = fav.food_id WHERE fav.user_id = ? ORDER BY f.name');
$fav->execute([$u['id']]);
$favorites = $fav->fetchAll();
$initials = strtoupper(substr(trim($u['name']), 0, 1));
$totalSpent = array_sum(array_map(fn($order) => (float)$order['total'], $orders));
$activeOrders = array_values(array_filter($orders, fn($order) => !in_array($order['status'], ['delivered', 'cancelled'], true)));
$latestOrder = $orders[0] ?? null;
$statusCounts = ['received' => 0, 'preparing' => 0, 'out for delivery' => 0, 'delivered' => 0];
foreach ($orders as $order) {
    if (isset($statusCounts[$order['status']])) {
        $statusCounts[$order['status']]++;
    }
}
$steps = ['received', 'preparing', 'out for delivery', 'delivered'];

require_once __DIR__ . '/../includes/header.php';
?>
<section class="customer-dashboard dashboard-shell">
    <section class="profile-hero dashboard-hero-card customer-hero-card">
        <div class="profile-photo-large">
            <?php if (!empty($u['profile_image'])): ?>
                <img src="<?= BASE_URL ?>/<?= e($u['profile_image']) ?>" alt="Profile picture">
            <?php else: ?>
                <span><?= e($initials) ?></span>
            <?php endif; ?>
        </div>
        <div class="customer-hero-copy">
            <p class="eyebrow">Customer Dashboard</p>
            <h1>Hi <?= e($u['name']) ?></h1>
            <p><?= e($u['email']) ?> &middot; <?= e($u['phone']) ?></p>
            <div class="quick-actions-row">
                <a class="button small" href="<?= BASE_URL ?>/public/menu.php">Order Food</a>
                <a class="ghost small" href="<?= BASE_URL ?>/public/reservation.php">Reserve Table</a>
            </div>
        </div>
        <form method="post" enctype="multipart/form-data" class="profile-upload-card">
            <strong>Profile Photo</strong>
            <span>Upload JPG, PNG, or WEBP</span>
            <input type="file" name="profile_image" accept="image/jpeg,image/png,image/webp" required>
            <button class="button small" type="submit">Update Photo</button>
        </form>
    </section>

    <section class="metric-grid">
        <article class="metric-card accent-a"><span>Total Orders</span><strong><?= count($orders) ?></strong><small>Orders placed by you</small></article>
        <article class="metric-card accent-b"><span>Active Orders</span><strong><?= count($activeOrders) ?></strong><small>Being handled now</small></article>
        <article class="metric-card accent-c"><span>Total Spent</span><strong>Rs. <?= number_format($totalSpent, 0) ?></strong><small>Across all orders</small></article>
        <article class="metric-card accent-d"><span>Favorites</span><strong><?= count($favorites) ?></strong><small>Saved food choices</small></article>
    </section>

    <section class="dashboard-grid">
        <article class="dashboard-panel wide-panel">
            <div class="panel-head"><div><p class="eyebrow">Order Journey</p><h2>Latest Order</h2></div><?php if ($latestOrder): ?><a class="ghost small" href="<?= BASE_URL ?>/public/order_tracking.php?id=<?= $latestOrder['id'] ?>">Track</a><?php endif; ?></div>
            <?php if ($latestOrder): ?>
                <div class="tracker compact-tracker"><?php foreach ($steps as $step): ?><div class="<?= array_search($step, $steps, true) <= array_search($latestOrder['status'], $steps, true) ? 'active' : '' ?>"><?= e(ucwords($step)) ?></div><?php endforeach; ?></div>
                <div class="order-summary-card"><strong>Order #<?= $latestOrder['id'] ?></strong><span><?= e(order_items_label((int)$latestOrder['id'])) ?></span><small><?= e($latestOrder['order_location'] ?? 'Location not provided') ?></small><em>Rs. <?= number_format((float)$latestOrder['total'], 2) ?></em></div>
            <?php else: ?>
                <p class="muted">Your latest order will appear here.</p>
            <?php endif; ?>
        </article>

        <article class="dashboard-panel">
            <div class="panel-head"><div><p class="eyebrow">Saved Locations</p><h2>Your Places</h2></div></div>
            <form method="post" class="location-form">
                <input name="label" placeholder="Label e.g. Home" required>
                <input name="address" placeholder="Full location/address" required>
                <button class="button small" name="save_location" value="1">Save Location</button>
            </form>
            <div class="saved-location-list">
                <?php foreach ($addresses as $address): ?>
                    <div class="saved-location-item"><div><strong><?= e($address['label']) ?></strong><span><?= e($address['address']) ?></span></div><form method="post"><input type="hidden" name="address_id" value="<?= $address['id'] ?>"><button class="ghost small" name="delete_location" value="1">Remove</button></form></div>
                <?php endforeach; ?>
                <?php if (!$addresses): ?><p class="muted">No saved locations yet.</p><?php endif; ?>
            </div>
        </article>
    </section>

    <section class="dashboard-panel">
        <div class="panel-head"><div><p class="eyebrow">Favorite Foods</p><h2>Your Saved Food List</h2></div><a class="ghost small" href="<?= BASE_URL ?>/public/menu.php">Browse Menu</a></div>
        <div class="favorite-food-list">
            <?php foreach ($favorites as $food): ?>
                <article class="favorite-food-card"><img src="<?= e($food['image_url']) ?>" alt="<?= e($food['name']) ?>"><div><strong><?= e($food['name']) ?></strong><span>Rs. <?= number_format((float)$food['price'], 2) ?></span><a class="ghost small" href="<?= BASE_URL ?>/public/menu.php">Order Again</a></div></article>
            <?php endforeach; ?>
            <?php if (!$favorites): ?><p class="muted">Your favorite foods will appear here after you save them from the menu.</p><?php endif; ?>
        </div>
    </section>

    <section class="dashboard-panel">
        <div class="panel-head"><div><p class="eyebrow">Order History</p><h2>Your Orders</h2></div><div class="filter-pills" data-filter-group="orders"><button class="active" data-filter="all" type="button">All</button><button data-filter="active" type="button">Active</button><button data-filter="delivered" type="button">Delivered</button></div></div>
        <div class="order-card-list">
            <?php foreach ($orders as $order): ?>
                <?php $group = in_array($order['status'], ['delivered', 'cancelled'], true) ? 'delivered' : 'active'; ?>
                <article class="order-card" data-order-status="<?= e($group) ?>"><div><strong>#<?= $order['id'] ?> &middot; <?= e(ucwords($order['status'])) ?></strong><span><?= e(order_items_label((int)$order['id'])) ?></span><small><?= e($order['created_at']) ?> &middot; <?= e($order['order_location'] ?? 'No location') ?></small></div><em>Rs. <?= number_format((float)$order['total'], 2) ?></em><a class="ghost small" href="<?= BASE_URL ?>/public/order_tracking.php?id=<?= $order['id'] ?>">Track</a></article>
            <?php endforeach; ?>
            <?php if (!$orders): ?><p class="muted">No orders yet. Start with your favorite food from the menu.</p><?php endif; ?>
        </div>
    </section>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
