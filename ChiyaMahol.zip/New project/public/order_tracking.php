<?php
require_once __DIR__ . '/../includes/functions.php';

$u = require_login();
$s = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$s->execute([(int)$_GET['id'], $u['id']]);
$o = $s->fetch();

if (!$o) {
    flash('Order not found.');
    redirect('/public/profile.php');
}

$items = order_items_for_order((int)$o['id']);
$steps = ['received', 'preparing', 'out for delivery', 'delivered'];
require_once __DIR__ . '/../includes/header.php';
?>
<h1>Order Tracking #<?= $o['id'] ?></h1>
<div class="tracker">
    <?php foreach ($steps as $st): ?>
        <div class="<?= array_search($st, $steps, true) <= array_search($o['status'], $steps, true) ? 'active' : '' ?>">
            <?= e(ucwords($st)) ?>
        </div>
    <?php endforeach; ?>
</div>
<section class="dashboard-panel order-items-panel">
    <div class="panel-head"><div><p class="eyebrow">Ordered Foods</p><h2>Your Food Items</h2></div></div>
    <div class="table-wrap embedded-table">
        <table>
            <tr><th>Food</th><th>Qty</th><th>Price</th><th>Total</th></tr>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= e($item['name']) ?></td>
                    <td><?= e((string)$item['quantity']) ?></td>
                    <td>Rs. <?= number_format((float)$item['price'], 2) ?></td>
                    <td>Rs. <?= number_format((float)$item['line_total'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</section>
<article>
    <p><strong>Total:</strong> Rs. <?= number_format((float)$o['total'], 2) ?></p>
    <p><strong>Payment:</strong> <?= e($o['payment_method']) ?></p>
    <p><strong>Location:</strong> <?= e($o['order_location'] ?? 'Not provided') ?></p>
    <?php if (!empty($o['special_instructions'])): ?>
        <p><strong>Instructions:</strong> <?= e($o['special_instructions']) ?></p>
    <?php endif; ?>
</article>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

