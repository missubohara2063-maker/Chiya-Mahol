<?php
require_once __DIR__ . '/../includes/functions.php';

$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['favorite'])) {
        $user = require_login();
        $id = (int)$_POST['food_id'];

        if ($_POST['favorite'] === 'add') {
            db()->prepare('INSERT IGNORE INTO favorites(user_id, food_id) VALUES(?, ?)')->execute([$user['id'], $id]);
            flash('Food added to favorites.');
        } else {
            db()->prepare('DELETE FROM favorites WHERE user_id = ? AND food_id = ?')->execute([$user['id'], $id]);
            flash('Food removed from favorites.');
        }

        redirect('/public/menu.php');
    }

    if (!$user) {
        flash('Please login first to add food to your cart.');
        redirect('/auth/login.php');
    }

    $id = (int)$_POST['food_id'];
    $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
    flash('Item added to cart.');
    redirect('/public/menu.php');
}

$category = $_GET['category'] ?? '';
$search = trim($_GET['search'] ?? '');
$params = [];
$where = ['1=1'];

if ($category !== '') {
    $where[] = 'c.id = ?';
    $params[] = $category;
}

if ($search !== '') {
    $where[] = 'f.name LIKE ?';
    $params[] = "%$search%";
}

$s = db()->prepare('SELECT f.*, c.name category_name FROM foods f JOIN categories c ON c.id = f.category_id WHERE ' . implode(' AND ', $where) . ' ORDER BY f.name');
$s->execute($params);
$foods = $s->fetchAll();
$cats = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$favorites = [];

if ($user) {
    $favStmt = db()->prepare('SELECT food_id FROM favorites WHERE user_id = ?');
    $favStmt->execute([$user['id']]);
    $favorites = array_flip(array_column($favStmt->fetchAll(), 'food_id'));
}

require_once __DIR__ . '/../includes/header.php';
?>
<section class="page-head">
    <h1>Food Menu</h1>
    <form class="filters">
        <input name="search" value="<?= e($search) ?>" placeholder="Search food">
        <select name="category">
            <option value="">All categories</option>
            <?php foreach ($cats as $c): ?>
                <option value="<?= $c['id'] ?>" <?= (string)$c['id'] === (string)$category ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <button class="button small">Filter</button>
    </form>
</section>
<section class="food-grid">
    <?php foreach ($foods as $f): ?>
        <?php $isFavorite = isset($favorites[$f['id']]); ?>
        <article class="food-card">
            <img src="<?= e($f['image_url']) ?>" alt="<?= e($f['name']) ?>">
            <div>
                <span class="pill"><?= e($f['category_name']) ?></span>
                <h3><?= e($f['name']) ?></h3>
                <p><?= e($f['description']) ?></p>
                <strong>Rs. <?= number_format((float)$f['price'], 2) ?></strong>
                <p class="<?= $f['is_available'] ? 'ok' : 'danger' ?>"><?= $f['is_available'] ? 'Available' : 'Unavailable' ?></p>
                <div class="food-actions">
                    <form method="post">
                        <input type="hidden" name="food_id" value="<?= $f['id'] ?>">
                        <button class="button small menu-action-btn cart-action" <?= $f['is_available'] ? '' : 'disabled' ?>>
                            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h2l1.4 8.4a2 2 0 0 0 2 1.6h6.9a2 2 0 0 0 1.9-1.4L21 10H8"/><path d="M9 7a3 3 0 0 1 6 0"/><circle cx="10" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/></svg>
                            <span>Add to Cart</span>
                        </button>
                    </form>
                    <form method="post">
                        <input type="hidden" name="food_id" value="<?= $f['id'] ?>">
                        <button class="ghost small menu-action-btn favorite-action <?= $isFavorite ? 'is-favorite' : '' ?>" name="favorite" value="<?= $isFavorite ? 'remove' : 'add' ?>" type="submit">
                            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>
                            <span><?= $isFavorite ? 'Saved' : 'Favourite' ?></span>
                        </button>
                    </form>
                    <a class="ghost small menu-action-btn review-action" href="<?= BASE_URL ?>/public/review.php?food_id=<?= $f['id'] ?>">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.2L5.8 21 7 14.2 2 9.3l6.9-1L12 2Z"/></svg>
                        <span>Review</span>
                    </a>
                </div>
            </div>
        </article>
    <?php endforeach; ?>
</section>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>



