<?php
define('APP_NAME', 'Chiya Mahol');
define('BASE_URL', '/chiya_mahol');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'chiya_mahol');
define('DB_USER', 'root');
define('DB_PASS', '');
date_default_timezone_set('Asia/Kathmandu');
