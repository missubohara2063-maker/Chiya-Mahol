<?php
// Gmail / Google Workspace SMTP settings for sending OTP emails.
// Put your Gmail App Password in SMTP_PASSWORD. Do not use your normal Gmail password.
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'missubohara2063@gmail.com');
define('SMTP_PASSWORD', 'gpks cirf ncih obwp');
define('SMTP_FROM_EMAIL', 'missubohara2063@gmail.com');
define('SMTP_FROM_NAME', 'Chiya Mahol');

